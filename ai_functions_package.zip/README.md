
# AI Functions Package

Contains:
- `functions_1000.json`: Metadata for 1000 placeholder functions across 20 categories.
- `server.js`: Sample Express.js server to list and invoke functions.

## Usage
1. `npm install express`
2. `node server.js`
3. GET /api/functions
4. POST /api/call/:id with JSON body to invoke.
