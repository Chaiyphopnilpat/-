
const express = require('express');
const app = express();
app.use(express.json());

// Load functions metadata
const functions = require('./functions_1000.json');

app.get('/api/functions', (req, res) => {
  res.json(functions);
});

app.post('/api/call/:id', (req, res) => {
  const fn = functions.find(f => f.id === req.params.id);
  if (!fn) return res.status(404).json({ error: 'Function not found' });
  // Placeholder execution
  res.json({ result: `Executed ${fn.name} with params ${JSON.stringify(req.body)}` });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
