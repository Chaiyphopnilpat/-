# ระบบแชทบอทอย่างง่าย
class ChatBot:
    def respond(self, message):
        return 'สวัสดี! ฉันคือแชทบอท'