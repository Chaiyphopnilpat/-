# ระบบควบคุมโมเดล 1 ล้านตัว
for i in range(1_000_000):
    print(f'Activating model {i}')