import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Star, Users, Zap, BarChart3, MessageSquare, ShoppingCart, Crown } from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"

const featuredProducts = [
  {
    id: 1,
    name: "AI Chatbot SaaS",
    description: "Embeddable AI assistant with custom training",
    price: 49,
    category: "AI & Automation",
    rating: 4.8,
    users: 1200,
    icon: MessageSquare,
    features: ["Custom Training", "Multi-language", "Analytics", "API Access"],
    popular: true,
  },
  {
    id: 2,
    name: "Analytics Tracker Pro",
    description: "Advanced analytics SDK with real-time insights",
    price: 29,
    category: "Analytics",
    rating: 4.6,
    users: 850,
    icon: BarChart3,
    features: ["Real-time Data", "Custom Dashboards", "Export Tools", "Team Sharing"],
    popular: false,
  },
  {
    id: 3,
    name: "CRM Lite Enterprise",
    description: "Lightweight CRM with powerful workflow automation",
    price: 79,
    category: "CRM & Sales",
    rating: 4.9,
    users: 2100,
    icon: Users,
    features: ["Lead Management", "Automation", "Integrations", "Mobile App"],
    popular: true,
  },
]

const categories = [
  { name: "AI & Automation", count: 24, icon: Zap },
  { name: "Analytics", count: 18, icon: BarChart3 },
  { name: "CRM & Sales", count: 15, icon: Users },
  { name: "E-commerce", count: 12, icon: ShoppingCart },
  { name: "Communication", count: 21, icon: MessageSquare },
]

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-white/20 text-white hover:bg-white/30">
              🚀 100+ Premium SaaS Solutions Available
            </Badge>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">SaaS Marketplace</h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90">
              Discover, purchase, and deploy ready-to-use SaaS applications. From AI chatbots to CRM systems -
              everything you need to scale your business.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search SaaS solutions..."
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/70"
                />
              </div>
              <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
                Explore Now
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Browse by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {categories.map((category) => {
              const Icon = category.icon
              return (
                <Link
                  key={category.name}
                  href={`/category/${category.name.toLowerCase().replace(" & ", "-").replace(" ", "-")}`}
                >
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardContent className="p-6 text-center">
                      <Icon className="h-8 w-8 mx-auto mb-3 text-blue-600 group-hover:text-purple-600 transition-colors" />
                      <h3 className="font-semibold mb-1">{category.name}</h3>
                      <p className="text-sm text-gray-600">{category.count} solutions</p>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Featured SaaS Solutions</h2>
            <Link href="/products">
              <Button variant="outline">View All Products</Button>
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => {
              const Icon = product.icon
              return (
                <Card key={product.id} className="relative hover:shadow-xl transition-shadow group">
                  {product.popular && (
                    <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-orange-500 to-pink-500">
                      <Crown className="h-3 w-3 mr-1" />
                      Popular
                    </Badge>
                  )}

                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Icon className="h-8 w-8 text-blue-600" />
                      <Badge variant="secondary">{product.category}</Badge>
                    </div>
                    <CardTitle className="text-xl">{product.name}</CardTitle>
                    <CardDescription>{product.description}</CardDescription>
                  </CardHeader>

                  <CardContent>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                        <span className="text-sm font-medium">{product.rating}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Users className="h-4 w-4 mr-1" />
                        {product.users.toLocaleString()} users
                      </div>
                    </div>

                    <div className="space-y-2">
                      {product.features.map((feature, index) => (
                        <div key={index} className="flex items-center text-sm">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </CardContent>

                  <CardFooter className="flex justify-between items-center">
                    <div>
                      <span className="text-2xl font-bold">${product.price}</span>
                      <span className="text-gray-600">/month</span>
                    </div>
                    <Link href={`/product/${product.id}`}>
                      <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">100+</div>
              <div className="text-blue-100">SaaS Solutions</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">50K+</div>
              <div className="text-blue-100">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">99.9%</div>
              <div className="text-blue-100">Uptime</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">24/7</div>
              <div className="text-blue-100">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Scale Your Business?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Join thousands of businesses using our SaaS marketplace to find the perfect tools for growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
