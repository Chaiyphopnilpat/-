"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Shield,
  Key,
  Search,
  CreditCard,
  Zap,
  Users,
  BarChart3,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Sparkles,
  Globe,
  Target,
  TrendingUp,
  DollarSign,
  RefreshCw,
  Download,
  Eye,
  Edit,
  Plus,
  Copy,
} from "lucide-react"
import { Header } from "@/components/header"
import { motion, AnimatePresence } from "framer-motion"

// Types
interface License {
  id: string
  key: string
  productName: string
  customerEmail: string
  status: "active" | "expired" | "suspended" | "pending"
  expiresAt: Date
  createdAt: Date
  usageCount: number
  maxUsage: number
}

interface SEOAnalysis {
  score: number
  keywords: string[]
  suggestions: string[]
  metaTitle: string
  metaDescription: string
  isOptimized: boolean
}

interface StripeProduct {
  id: string
  name: string
  price: number
  currency: string
  interval: "month" | "year"
  features: string[]
}

// Mock Data
const mockLicenses: License[] = [
  {
    id: "1",
    key: "SAAS-2024-PREMIUM-ABC123",
    productName: "AI Chatbot Pro",
    customerEmail: "john@example.com",
    status: "active",
    expiresAt: new Date("2024-12-31"),
    createdAt: new Date("2024-01-15"),
    usageCount: 1250,
    maxUsage: 5000,
  },
  {
    id: "2",
    key: "SAAS-2024-BASIC-XYZ789",
    productName: "Analytics Dashboard",
    customerEmail: "sarah@example.com",
    status: "expired",
    expiresAt: new Date("2024-06-30"),
    createdAt: new Date("2024-01-10"),
    usageCount: 2100,
    maxUsage: 2000,
  },
  {
    id: "3",
    key: "SAAS-2024-ENTERPRISE-DEF456",
    productName: "CRM Suite",
    customerEmail: "mike@company.com",
    status: "active",
    expiresAt: new Date("2025-01-31"),
    createdAt: new Date("2024-02-01"),
    usageCount: 850,
    maxUsage: 10000,
  },
]

const stripeProducts: StripeProduct[] = [
  {
    id: "price_basic",
    name: "Basic Plan",
    price: 29,
    currency: "USD",
    interval: "month",
    features: ["Up to 1,000 API calls", "Basic support", "Standard features"],
  },
  {
    id: "price_pro",
    name: "Professional Plan",
    price: 79,
    currency: "USD",
    interval: "month",
    features: ["Up to 10,000 API calls", "Priority support", "Advanced features", "Analytics dashboard"],
  },
  {
    id: "price_enterprise",
    name: "Enterprise Plan",
    price: 199,
    currency: "USD",
    interval: "month",
    features: ["Unlimited API calls", "24/7 support", "All features", "Custom integrations", "Dedicated manager"],
  },
]

export default function MarketplaceControlPage() {
  const [licenses, setLicenses] = useState<License[]>(mockLicenses)
  const [licenseKey, setLicenseKey] = useState("")
  const [validationResult, setValidationResult] = useState<{
    isValid: boolean
    message: string
    license?: License
  } | null>(null)
  const [seoAnalysis, setSeoAnalysis] = useState<SEOAnalysis | null>(null)
  const [seoUrl, setSeoUrl] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<StripeProduct | null>(null)
  const [isProcessingPayment, setIsProcessingPayment] = useState(false)

  // License Control Functions
  const validateLicense = async () => {
    if (!licenseKey.trim()) return

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const license = licenses.find((l) => l.key === licenseKey)
    if (license) {
      const isExpired = new Date() > license.expiresAt
      const isOverUsage = license.usageCount >= license.maxUsage

      setValidationResult({
        isValid: license.status === "active" && !isExpired && !isOverUsage,
        message: isExpired
          ? "License has expired"
          : isOverUsage
            ? "Usage limit exceeded"
            : license.status !== "active"
              ? `License is ${license.status}`
              : "License is valid and active",
        license,
      })
    } else {
      setValidationResult({
        isValid: false,
        message: "License key not found",
      })
    }
  }

  const generateLicense = () => {
    const newKey = `SAAS-${new Date().getFullYear()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    setLicenseKey(newKey)
  }

  const suspendLicense = (licenseId: string) => {
    setLicenses(licenses.map((license) => (license.id === licenseId ? { ...license, status: "suspended" } : license)))
  }

  const activateLicense = (licenseId: string) => {
    setLicenses(licenses.map((license) => (license.id === licenseId ? { ...license, status: "active" } : license)))
  }

  // SEO AI Functions
  const runSeoAnalysis = async () => {
    if (!seoUrl.trim()) return

    setIsAnalyzing(true)
    // Simulate AI analysis
    await new Promise((resolve) => setTimeout(resolve, 3000))

    const mockAnalysis: SEOAnalysis = {
      score: Math.floor(Math.random() * 40) + 60, // 60-100
      keywords: ["saas marketplace", "software licensing", "api management", "business automation"],
      suggestions: [
        "Optimize meta title length (currently too long)",
        "Add more internal links to improve site structure",
        "Improve page loading speed (currently 3.2s)",
        "Add alt text to 3 images missing descriptions",
        "Include more long-tail keywords in content",
      ],
      metaTitle: "SaaS Marketplace - Premium Software Solutions",
      metaDescription:
        "Discover and purchase premium SaaS applications. Streamline your business with our curated marketplace of professional software solutions.",
      isOptimized: Math.random() > 0.5,
    }

    setSeoAnalysis(mockAnalysis)
    setIsAnalyzing(false)
  }

  const optimizeWithAI = async () => {
    if (!seoAnalysis) return

    setIsAnalyzing(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setSeoAnalysis({
      ...seoAnalysis,
      score: Math.min(100, seoAnalysis.score + Math.floor(Math.random() * 20) + 10),
      isOptimized: true,
      suggestions: seoAnalysis.suggestions.slice(0, 2), // Reduce suggestions
    })
    setIsAnalyzing(false)
  }

  // Stripe Functions
  const handleStripeCheckout = async (product: StripeProduct) => {
    setSelectedProduct(product)
    setIsProcessingPayment(true)

    // Simulate Stripe checkout
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // In real implementation, redirect to Stripe Checkout
    alert(`Redirecting to Stripe Checkout for ${product.name} - $${product.price}/${product.interval}`)
    setIsProcessingPayment(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500"
      case "expired":
        return "bg-red-500"
      case "suspended":
        return "bg-yellow-500"
      case "pending":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  const getUsagePercentage = (used: number, max: number) => {
    return Math.min(100, (used / max) * 100)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            🚀 SaaS Marketplace Control Center
          </h1>
          <p className="text-gray-600">Advanced license management, SEO optimization, and payment processing</p>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Active Licenses</p>
                  <p className="text-3xl font-bold">{licenses.filter((l) => l.status === "active").length}</p>
                </div>
                <Shield className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">SEO Score</p>
                  <p className="text-3xl font-bold">{seoAnalysis?.score || "--"}/100</p>
                </div>
                <Search className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Monthly Revenue</p>
                  <p className="text-3xl font-bold">$12.5K</p>
                </div>
                <DollarSign className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">Total Users</p>
                  <p className="text-3xl font-bold">1,247</p>
                </div>
                <Users className="h-8 w-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Main Tabs */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Tabs defaultValue="license" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="license" className="flex items-center gap-2">
                <Key className="h-4 w-4" />
                License Control
              </TabsTrigger>
              <TabsTrigger value="seo" className="flex items-center gap-2">
                <Sparkles className="h-4 w-4" />
                SEO AI
              </TabsTrigger>
              <TabsTrigger value="billing" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Stripe Checkout
              </TabsTrigger>
            </TabsList>

            {/* License Control Tab */}
            <TabsContent value="license" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* License Validation */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      License Validation
                    </CardTitle>
                    <CardDescription>Validate and manage license keys</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="license-key">License Key</Label>
                      <div className="flex gap-2">
                        <Input
                          id="license-key"
                          placeholder="Enter license key..."
                          value={licenseKey}
                          onChange={(e) => setLicenseKey(e.target.value)}
                        />
                        <Button variant="outline" onClick={generateLicense}>
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <Button onClick={validateLicense} className="w-full" disabled={!licenseKey.trim()}>
                      <Key className="h-4 w-4 mr-2" />
                      Validate License
                    </Button>

                    <AnimatePresence>
                      {validationResult && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className={`p-4 rounded-lg border ${
                            validationResult.isValid ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                          }`}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            {validationResult.isValid ? (
                              <CheckCircle className="h-5 w-5 text-green-600" />
                            ) : (
                              <XCircle className="h-5 w-5 text-red-600" />
                            )}
                            <span
                              className={`font-medium ${validationResult.isValid ? "text-green-800" : "text-red-800"}`}
                            >
                              {validationResult.message}
                            </span>
                          </div>
                          {validationResult.license && (
                            <div className="text-sm space-y-1">
                              <p>
                                <strong>Product:</strong> {validationResult.license.productName}
                              </p>
                              <p>
                                <strong>Customer:</strong> {validationResult.license.customerEmail}
                              </p>
                              <p>
                                <strong>Usage:</strong> {validationResult.license.usageCount}/
                                {validationResult.license.maxUsage}
                              </p>
                              <p>
                                <strong>Expires:</strong> {validationResult.license.expiresAt.toLocaleDateString()}
                              </p>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                    <CardDescription>Common license management tasks</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center bg-transparent"
                      >
                        <Plus className="h-6 w-6 mb-2" />
                        Generate License
                      </Button>
                      <Button
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center bg-transparent"
                      >
                        <Download className="h-6 w-6 mb-2" />
                        Export Licenses
                      </Button>
                      <Button
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center bg-transparent"
                      >
                        <RefreshCw className="h-6 w-6 mb-2" />
                        Bulk Renewal
                      </Button>
                      <Button
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center bg-transparent"
                      >
                        <BarChart3 className="h-6 w-6 mb-2" />
                        Usage Analytics
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* License Management Table */}
              <Card>
                <CardHeader>
                  <CardTitle>License Management</CardTitle>
                  <CardDescription>Manage all active licenses and their status</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>License Key</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Usage</TableHead>
                        <TableHead>Expires</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {licenses.map((license) => (
                        <TableRow key={license.id}>
                          <TableCell className="font-mono text-sm">
                            <div className="flex items-center gap-2">
                              {license.key}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => navigator.clipboard.writeText(license.key)}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          </TableCell>
                          <TableCell>{license.productName}</TableCell>
                          <TableCell>{license.customerEmail}</TableCell>
                          <TableCell>
                            <Badge className={`${getStatusColor(license.status)} text-white`}>{license.status}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="w-16 bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-blue-600 h-2 rounded-full"
                                  style={{ width: `${getUsagePercentage(license.usageCount, license.maxUsage)}%` }}
                                />
                              </div>
                              <span className="text-sm">
                                {license.usageCount}/{license.maxUsage}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>{license.expiresAt.toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button variant="ghost" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              {license.status === "active" ? (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => suspendLicense(license.id)}
                                  className="text-yellow-600"
                                >
                                  <AlertTriangle className="h-4 w-4" />
                                </Button>
                              ) : (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => activateLicense(license.id)}
                                  className="text-green-600"
                                >
                                  <CheckCircle className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* SEO AI Tab */}
            <TabsContent value="seo" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* SEO Analysis */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Sparkles className="h-5 w-5" />
                      AI-Powered SEO Analysis
                    </CardTitle>
                    <CardDescription>Analyze and optimize your website's SEO performance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="seo-url">Website URL</Label>
                      <Input
                        id="seo-url"
                        placeholder="https://your-website.com"
                        value={seoUrl}
                        onChange={(e) => setSeoUrl(e.target.value)}
                      />
                    </div>

                    <Button onClick={runSeoAnalysis} disabled={isAnalyzing || !seoUrl.trim()} className="w-full">
                      {isAnalyzing ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Search className="h-4 w-4 mr-2" />
                          Run SEO Analysis
                        </>
                      )}
                    </Button>

                    {seoAnalysis && (
                      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">SEO Score</span>
                          <Badge
                            className={`${
                              seoAnalysis.score >= 80
                                ? "bg-green-500"
                                : seoAnalysis.score >= 60
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            } text-white`}
                          >
                            {seoAnalysis.score}/100
                          </Badge>
                        </div>

                        <div className="w-full bg-gray-200 rounded-full h-3">
                          <div
                            className={`h-3 rounded-full ${
                              seoAnalysis.score >= 80
                                ? "bg-green-500"
                                : seoAnalysis.score >= 60
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${seoAnalysis.score}%` }}
                          />
                        </div>

                        <Button
                          onClick={optimizeWithAI}
                          disabled={isAnalyzing || seoAnalysis.isOptimized}
                          className="w-full"
                        >
                          {isAnalyzing ? (
                            <>
                              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                              Optimizing...
                            </>
                          ) : seoAnalysis.isOptimized ? (
                            <>
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Optimized
                            </>
                          ) : (
                            <>
                              <Zap className="h-4 w-4 mr-2" />
                              Optimize with AI
                            </>
                          )}
                        </Button>
                      </motion.div>
                    )}
                  </CardContent>
                </Card>

                {/* SEO Insights */}
                <Card>
                  <CardHeader>
                    <CardTitle>SEO Insights</CardTitle>
                    <CardDescription>Detailed analysis and recommendations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {seoAnalysis ? (
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">Keywords Found</h4>
                          <div className="flex flex-wrap gap-2">
                            {seoAnalysis.keywords.map((keyword, index) => (
                              <Badge key={index} variant="outline">
                                {keyword}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Meta Information</h4>
                          <div className="space-y-2 text-sm">
                            <div>
                              <strong>Title:</strong> {seoAnalysis.metaTitle}
                            </div>
                            <div>
                              <strong>Description:</strong> {seoAnalysis.metaDescription}
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Recommendations</h4>
                          <div className="space-y-2">
                            {seoAnalysis.suggestions.map((suggestion, index) => (
                              <div key={index} className="flex items-start gap-2 text-sm">
                                <Target className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                {suggestion}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>Run an SEO analysis to see insights</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* SEO Tools */}
              <Card>
                <CardHeader>
                  <CardTitle>SEO Optimization Tools</CardTitle>
                  <CardDescription>Advanced tools for SEO management</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="p-4 bg-blue-50 rounded-lg mb-4">
                        <Target className="h-8 w-8 text-blue-600 mx-auto" />
                      </div>
                      <h3 className="font-semibold mb-2">Keyword Research</h3>
                      <p className="text-sm text-gray-600 mb-4">AI-powered keyword discovery and analysis</p>
                      <Button variant="outline" size="sm" className="bg-transparent">
                        Research Keywords
                      </Button>
                    </div>

                    <div className="text-center">
                      <div className="p-4 bg-green-50 rounded-lg mb-4">
                        <TrendingUp className="h-8 w-8 text-green-600 mx-auto" />
                      </div>
                      <h3 className="font-semibold mb-2">Rank Tracking</h3>
                      <p className="text-sm text-gray-600 mb-4">Monitor your search engine rankings</p>
                      <Button variant="outline" size="sm" className="bg-transparent">
                        Track Rankings
                      </Button>
                    </div>

                    <div className="text-center">
                      <div className="p-4 bg-purple-50 rounded-lg mb-4">
                        <Globe className="h-8 w-8 text-purple-600 mx-auto" />
                      </div>
                      <h3 className="font-semibold mb-2">Site Audit</h3>
                      <p className="text-sm text-gray-600 mb-4">Comprehensive technical SEO analysis</p>
                      <Button variant="outline" size="sm" className="bg-transparent">
                        Run Audit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Stripe Checkout Tab */}
            <TabsContent value="billing" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Stripe Payment Plans
                  </CardTitle>
                  <CardDescription>Secure payment processing with Stripe</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    {stripeProducts.map((product, index) => (
                      <motion.div
                        key={product.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <Card className={`relative ${index === 1 ? "border-blue-600 shadow-lg" : ""}`}>
                          {index === 1 && (
                            <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600">
                              Most Popular
                            </Badge>
                          )}
                          <CardHeader className="text-center">
                            <CardTitle>{product.name}</CardTitle>
                            <div className="text-3xl font-bold">
                              ${product.price}
                              <span className="text-sm font-normal text-gray-600">/{product.interval}</span>
                            </div>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <ul className="space-y-2">
                              {product.features.map((feature, featureIndex) => (
                                <li key={featureIndex} className="flex items-center text-sm">
                                  <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                                  {feature}
                                </li>
                              ))}
                            </ul>
                            <Button
                              className="w-full"
                              onClick={() => handleStripeCheckout(product)}
                              disabled={isProcessingPayment}
                            >
                              {isProcessingPayment && selectedProduct?.id === product.id ? (
                                <>
                                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                  Processing...
                                </>
                              ) : (
                                <>
                                  <CreditCard className="h-4 w-4 mr-2" />
                                  Choose Plan
                                </>
                              )}
                            </Button>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Payment History */}
              <Card>
                <CardHeader>
                  <CardTitle>Payment History</CardTitle>
                  <CardDescription>Recent transactions and billing information</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Plan</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Invoice</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {[
                        {
                          date: "2024-01-15",
                          plan: "Professional Plan",
                          amount: "$79.00",
                          status: "paid",
                          invoice: "INV-001",
                        },
                        {
                          date: "2023-12-15",
                          plan: "Professional Plan",
                          amount: "$79.00",
                          status: "paid",
                          invoice: "INV-002",
                        },
                        {
                          date: "2023-11-15",
                          plan: "Basic Plan",
                          amount: "$29.00",
                          status: "paid",
                          invoice: "INV-003",
                        },
                      ].map((payment, index) => (
                        <TableRow key={index}>
                          <TableCell>{payment.date}</TableCell>
                          <TableCell>{payment.plan}</TableCell>
                          <TableCell className="font-medium">{payment.amount}</TableCell>
                          <TableCell>
                            <Badge className="bg-green-500 text-white">Paid</Badge>
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4 mr-1" />
                              {payment.invoice}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  )
}
