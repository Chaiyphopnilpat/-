import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Marketplace Control Center - SaaS Marketplace",
  description: "Advanced license management, SEO optimization, and payment processing",
}

export default function MarketplaceControlLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
