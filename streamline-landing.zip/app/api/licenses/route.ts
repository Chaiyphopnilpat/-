import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { productId, plan = "professional" } = await req.json()

    // Check if user already has a license for this product
    const existingLicense = await prisma.license.findUnique({
      where: {
        userId_productId: {
          userId: session.user.id,
          productId: Number.parseInt(productId),
        },
      },
    })

    if (existingLicense) {
      return NextResponse.json({ error: "License already exists" }, { status: 400 })
    }

    // Create new license
    const license = await prisma.license.create({
      data: {
        userId: session.user.id,
        productId: Number.parseInt(productId),
        plan,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      },
      include: {
        product: true,
      },
    })

    return NextResponse.json(license)
  } catch (error) {
    console.error("License creation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const licenses = await prisma.license.findMany({
      where: {
        userId: session.user.id,
      },
      include: {
        product: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    })

    return NextResponse.json(licenses)
  } catch (error) {
    console.error("License fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
