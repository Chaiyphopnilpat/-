import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "HTTP Client & API Tester - SaaS Marketplace",
  description: "Professional API testing and monitoring tool",
}

export default function HttpAppLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
