"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Send, Code, Clock, Activity, FileText, Copy, Save, Trash2, Plus, Shield, Eye, EyeOff } from "lucide-react"
import { Header } from "@/components/header"

interface HttpRequest {
  id: string
  name: string
  method: string
  url: string
  headers: Record<string, string>
  body?: string
  createdAt: Date
}

interface HttpResponse {
  status: number
  statusText: string
  headers: Record<string, string>
  body: string
  responseTime: number
  size: number
}

const HTTP_METHODS = [
  { value: "GET", color: "bg-green-500" },
  { value: "POST", color: "bg-blue-500" },
  { value: "PUT", color: "bg-yellow-500" },
  { value: "PATCH", color: "bg-orange-500" },
  { value: "DELETE", color: "bg-red-500" },
  { value: "HEAD", color: "bg-purple-500" },
  { value: "OPTIONS", color: "bg-gray-500" },
]

const SAMPLE_REQUESTS: HttpRequest[] = [
  {
    id: "1",
    name: "Get Users",
    method: "GET",
    url: "https://jsonplaceholder.typicode.com/users",
    headers: { "Content-Type": "application/json" },
    createdAt: new Date(),
  },
  {
    id: "2",
    name: "Create Post",
    method: "POST",
    url: "https://jsonplaceholder.typicode.com/posts",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: "Test Post", body: "This is a test post", userId: 1 }),
    createdAt: new Date(),
  },
  {
    id: "3",
    name: "Update User",
    method: "PUT",
    url: "https://jsonplaceholder.typicode.com/users/1",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: "Updated Name", email: "updated@example.com" }),
    createdAt: new Date(),
  },
]

export default function HttpApp() {
  const [currentRequest, setCurrentRequest] = useState<HttpRequest>({
    id: "",
    name: "New Request",
    method: "GET",
    url: "",
    headers: { "Content-Type": "application/json" },
    createdAt: new Date(),
  })
  const [response, setResponse] = useState<HttpResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [savedRequests, setSavedRequests] = useState<HttpRequest[]>(SAMPLE_REQUESTS)
  const [showHeaders, setShowHeaders] = useState(false)
  const [headerKey, setHeaderKey] = useState("")
  const [headerValue, setHeaderValue] = useState("")

  const handleSendRequest = async () => {
    if (!currentRequest.url) return

    setLoading(true)
    const startTime = Date.now()

    try {
      const response = await fetch(currentRequest.url, {
        method: currentRequest.method,
        headers: currentRequest.headers,
        body: currentRequest.method !== "GET" ? currentRequest.body : undefined,
      })

      const responseTime = Date.now() - startTime
      const responseText = await response.text()
      const responseSize = new Blob([responseText]).size

      setResponse({
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        body: responseText,
        responseTime,
        size: responseSize,
      })
    } catch (error) {
      setResponse({
        status: 0,
        statusText: "Network Error",
        headers: {},
        body: JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
        responseTime: Date.now() - startTime,
        size: 0,
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSaveRequest = () => {
    const newRequest = {
      ...currentRequest,
      id: Date.now().toString(),
      createdAt: new Date(),
    }
    setSavedRequests([newRequest, ...savedRequests])
  }

  const handleLoadRequest = (request: HttpRequest) => {
    setCurrentRequest(request)
    setResponse(null)
  }

  const handleDeleteRequest = (id: string) => {
    setSavedRequests(savedRequests.filter((req) => req.id !== id))
  }

  const addHeader = () => {
    if (headerKey && headerValue) {
      setCurrentRequest({
        ...currentRequest,
        headers: {
          ...currentRequest.headers,
          [headerKey]: headerValue,
        },
      })
      setHeaderKey("")
      setHeaderValue("")
    }
  }

  const removeHeader = (key: string) => {
    const newHeaders = { ...currentRequest.headers }
    delete newHeaders[key]
    setCurrentRequest({
      ...currentRequest,
      headers: newHeaders,
    })
  }

  const formatJson = (jsonString: string) => {
    try {
      return JSON.stringify(JSON.parse(jsonString), null, 2)
    } catch {
      return jsonString
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const getMethodColor = (method: string) => {
    return HTTP_METHODS.find((m) => m.value === method)?.color || "bg-gray-500"
  }

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return "text-green-600"
    if (status >= 300 && status < 400) return "text-yellow-600"
    if (status >= 400 && status < 500) return "text-orange-600"
    if (status >= 500) return "text-red-600"
    return "text-gray-600"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            🌐 HTTP Client & API Tester
          </h1>
          <p className="text-gray-600">Professional API testing and monitoring tool</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar - Saved Requests */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Saved Requests
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {savedRequests.map((request) => (
                    <div
                      key={request.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                      onClick={() => handleLoadRequest(request)}
                    >
                      <div className="flex items-center gap-2">
                        <Badge className={`${getMethodColor(request.method)} text-white text-xs`}>
                          {request.method}
                        </Badge>
                        <span className="text-sm font-medium truncate">{request.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDeleteRequest(request.id)
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button
                  className="w-full mt-4 bg-transparent"
                  variant="outline"
                  onClick={() => {
                    setCurrentRequest({
                      id: "",
                      name: "New Request",
                      method: "GET",
                      url: "",
                      headers: { "Content-Type": "application/json" },
                      createdAt: new Date(),
                    })
                    setResponse(null)
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  New Request
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="grid gap-6">
              {/* Request Builder */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Request Builder</CardTitle>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={handleSaveRequest}>
                        <Save className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                      <Button onClick={handleSendRequest} disabled={loading || !currentRequest.url}>
                        {loading ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send className="h-4 w-4 mr-2" />
                            Send
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Request Name */}
                  <div>
                    <Label htmlFor="request-name">Request Name</Label>
                    <Input
                      id="request-name"
                      value={currentRequest.name}
                      onChange={(e) => setCurrentRequest({ ...currentRequest, name: e.target.value })}
                      placeholder="Enter request name..."
                    />
                  </div>

                  {/* Method and URL */}
                  <div className="flex gap-4">
                    <div className="w-32">
                      <Label htmlFor="method">Method</Label>
                      <Select
                        value={currentRequest.method}
                        onValueChange={(value) => setCurrentRequest({ ...currentRequest, method: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {HTTP_METHODS.map((method) => (
                            <SelectItem key={method.value} value={method.value}>
                              <div className="flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${method.color}`} />
                                {method.value}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="url">URL</Label>
                      <Input
                        id="url"
                        value={currentRequest.url}
                        onChange={(e) => setCurrentRequest({ ...currentRequest, url: e.target.value })}
                        placeholder="https://api.example.com/endpoint"
                      />
                    </div>
                  </div>

                  {/* Headers */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label>Headers</Label>
                      <Button variant="ghost" size="sm" onClick={() => setShowHeaders(!showHeaders)}>
                        {showHeaders ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    {showHeaders && (
                      <div className="space-y-2">
                        <div className="flex gap-2">
                          <Input
                            placeholder="Header key"
                            value={headerKey}
                            onChange={(e) => setHeaderKey(e.target.value)}
                          />
                          <Input
                            placeholder="Header value"
                            value={headerValue}
                            onChange={(e) => setHeaderValue(e.target.value)}
                          />
                          <Button onClick={addHeader}>Add</Button>
                        </div>
                        <div className="space-y-1">
                          {Object.entries(currentRequest.headers).map(([key, value]) => (
                            <div key={key} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                              <span className="text-sm">
                                <strong>{key}:</strong> {value}
                              </span>
                              <Button variant="ghost" size="sm" onClick={() => removeHeader(key)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Body */}
                  {currentRequest.method !== "GET" && currentRequest.method !== "HEAD" && (
                    <div>
                      <Label htmlFor="body">Request Body</Label>
                      <Textarea
                        id="body"
                        value={currentRequest.body || ""}
                        onChange={(e) => setCurrentRequest({ ...currentRequest, body: e.target.value })}
                        placeholder="Enter request body (JSON, XML, etc.)"
                        rows={8}
                      />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Response */}
              {response && (
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Response</CardTitle>
                      <div className="flex items-center gap-4">
                        <Badge className={`${getStatusColor(response.status)} bg-transparent border`}>
                          {response.status} {response.statusText}
                        </Badge>
                        <Badge variant="outline">
                          <Clock className="h-3 w-3 mr-1" />
                          {response.responseTime}ms
                        </Badge>
                        <Badge variant="outline">
                          <Activity className="h-3 w-3 mr-1" />
                          {response.size} bytes
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="body" className="w-full">
                      <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="body">Response Body</TabsTrigger>
                        <TabsTrigger value="headers">Headers</TabsTrigger>
                        <TabsTrigger value="raw">Raw</TabsTrigger>
                      </TabsList>

                      <TabsContent value="body" className="mt-4">
                        <div className="relative">
                          <Button
                            variant="outline"
                            size="sm"
                            className="absolute top-2 right-2 z-10 bg-transparent"
                            onClick={() => copyToClipboard(response.body)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <pre className="bg-gray-50 p-4 rounded-lg overflow-auto max-h-96 text-sm">
                            {formatJson(response.body)}
                          </pre>
                        </div>
                      </TabsContent>

                      <TabsContent value="headers" className="mt-4">
                        <div className="space-y-2">
                          {Object.entries(response.headers).map(([key, value]) => (
                            <div key={key} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                              <span className="text-sm">
                                <strong>{key}:</strong> {value}
                              </span>
                              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(`${key}: ${value}`)}>
                                <Copy className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </TabsContent>

                      <TabsContent value="raw" className="mt-4">
                        <div className="relative">
                          <Button
                            variant="outline"
                            size="sm"
                            className="absolute top-2 right-2 z-10 bg-transparent"
                            onClick={() => copyToClipboard(response.body)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <pre className="bg-gray-50 p-4 rounded-lg overflow-auto max-h-96 text-sm font-mono">
                            {response.body}
                          </pre>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              )}

              {/* API Documentation */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-5 w-5" />
                    API Testing Examples
                  </CardTitle>
                  <CardDescription>Common API testing scenarios and examples</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <h4 className="font-semibold">REST API Testing</h4>
                      <div className="space-y-2">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className="bg-green-500 text-white text-xs">GET</Badge>
                            <span className="text-sm font-medium">Fetch Resources</span>
                          </div>
                          <code className="text-xs text-gray-600">GET /api/users</code>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className="bg-blue-500 text-white text-xs">POST</Badge>
                            <span className="text-sm font-medium">Create Resource</span>
                          </div>
                          <code className="text-xs text-gray-600">POST /api/users</code>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className="bg-red-500 text-white text-xs">DELETE</Badge>
                            <span className="text-sm font-medium">Delete Resource</span>
                          </div>
                          <code className="text-xs text-gray-600">DELETE /api/users/1</code>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-semibold">Authentication</h4>
                      <div className="space-y-2">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Shield className="h-4 w-4 text-blue-600" />
                            <span className="text-sm font-medium">Bearer Token</span>
                          </div>
                          <code className="text-xs text-gray-600">Authorization: Bearer {"{token}"}</code>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Shield className="h-4 w-4 text-green-600" />
                            <span className="text-sm font-medium">API Key</span>
                          </div>
                          <code className="text-xs text-gray-600">X-API-Key: {"{api-key}"}</code>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Shield className="h-4 w-4 text-purple-600" />
                            <span className="text-sm font-medium">Basic Auth</span>
                          </div>
                          <code className="text-xs text-gray-600">Authorization: Basic {"{base64}"}</code>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
