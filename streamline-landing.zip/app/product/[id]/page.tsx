import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, Users, Shield, Zap, Check, ArrowLeft, MessageSquare, BarChart3 } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/header"

// Mock data - in real app, fetch from database
const getProduct = (id: string) => {
  const products = {
    "1": {
      id: 1,
      name: "AI Chatbot SaaS",
      description: "Embeddable AI assistant with custom training capabilities",
      longDescription:
        "Transform your customer support with our advanced AI chatbot. Features include natural language processing, custom training on your data, multi-language support, and seamless integration with popular platforms.",
      price: 49,
      category: "AI & Automation",
      rating: 4.8,
      users: 1200,
      icon: MessageSquare,
      images: ["/placeholder.svg?height=400&width=600&text=AI+Chatbot+Dashboard"],
      features: [
        "Custom AI Training",
        "Multi-language Support",
        "Real-time Analytics",
        "API Access",
        "White-label Solution",
        "24/7 Support",
      ],
      plans: [
        {
          name: "Starter",
          price: 29,
          features: ["Up to 1,000 conversations/month", "Basic customization", "Email support"],
        },
        {
          name: "Professional",
          price: 49,
          features: [
            "Up to 10,000 conversations/month",
            "Advanced customization",
            "Priority support",
            "Analytics dashboard",
          ],
        },
        {
          name: "Enterprise",
          price: 99,
          features: [
            "Unlimited conversations",
            "Full customization",
            "Dedicated support",
            "Advanced analytics",
            "API access",
          ],
        },
      ],
      demo: "/demo/chatbot",
      documentation: "/docs/chatbot",
    },
    "2": {
      id: 2,
      name: "Analytics Tracker Pro",
      description: "Advanced analytics SDK with real-time insights",
      longDescription:
        "Get deep insights into your application performance with our comprehensive analytics platform. Track user behavior, monitor performance metrics, and make data-driven decisions.",
      price: 29,
      category: "Analytics",
      rating: 4.6,
      users: 850,
      icon: BarChart3,
      images: ["/placeholder.svg?height=400&width=600&text=Analytics+Dashboard"],
      features: [
        "Real-time Data Processing",
        "Custom Dashboards",
        "Export Tools",
        "Team Collaboration",
        "API Integration",
        "Mobile Analytics",
      ],
      plans: [
        { name: "Basic", price: 19, features: ["Up to 10K events/month", "Basic dashboards", "Email support"] },
        {
          name: "Pro",
          price: 29,
          features: ["Up to 100K events/month", "Custom dashboards", "Priority support", "Data export"],
        },
        {
          name: "Enterprise",
          price: 59,
          features: ["Unlimited events", "Advanced analytics", "Dedicated support", "Custom integrations"],
        },
      ],
      demo: "/demo/analytics",
      documentation: "/docs/analytics",
    },
    "3": {
      id: 3,
      name: "CRM Lite Enterprise",
      description: "Lightweight CRM with powerful workflow automation",
      longDescription:
        "Streamline your sales process with our intuitive CRM system. Manage leads, automate workflows, and close more deals with powerful automation features.",
      price: 79,
      category: "CRM & Sales",
      rating: 4.9,
      users: 2100,
      icon: Users,
      images: ["/placeholder.svg?height=400&width=600&text=CRM+Dashboard"],
      features: [
        "Lead Management",
        "Workflow Automation",
        "Third-party Integrations",
        "Mobile App",
        "Sales Pipeline",
        "Reporting & Analytics",
      ],
      plans: [
        { name: "Starter", price: 39, features: ["Up to 1,000 contacts", "Basic automation", "Email support"] },
        {
          name: "Professional",
          price: 79,
          features: ["Up to 10,000 contacts", "Advanced automation", "Priority support", "Mobile app"],
        },
        {
          name: "Enterprise",
          price: 149,
          features: ["Unlimited contacts", "Custom workflows", "Dedicated support", "Advanced integrations"],
        },
      ],
      demo: "/demo/crm",
      documentation: "/docs/crm",
    },
  }

  return products[id as keyof typeof products] || null
}

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = getProduct(params.id)

  if (!product) {
    return <div>Product not found</div>
  }

  const Icon = product.icon

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-6">
          <Link href="/" className="flex items-center text-sm text-gray-600 hover:text-blue-600">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Marketplace
          </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Product Header */}
            <div className="bg-white rounded-lg p-6 mb-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold">{product.name}</h1>
                    <p className="text-gray-600">{product.description}</p>
                  </div>
                </div>
                <Badge variant="secondary">{product.category}</Badge>
              </div>

              <div className="flex items-center gap-6 mb-6">
                <div className="flex items-center">
                  <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 mr-1" />
                  <span className="font-medium">{product.rating}</span>
                  <span className="text-gray-600 ml-1">(124 reviews)</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Users className="h-4 w-4 mr-1" />
                  {product.users.toLocaleString()} active users
                </div>
                <div className="flex items-center text-green-600">
                  <Shield className="h-4 w-4 mr-1" />
                  Verified Publisher
                </div>
              </div>

              {/* Product Image */}
              <div className="mb-6">
                <Image
                  src={product.images[0] || "/placeholder.svg"}
                  alt={product.name}
                  width={600}
                  height={400}
                  className="w-full rounded-lg border"
                />
              </div>

              {/* Tabs */}
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="features">Features</TabsTrigger>
                  <TabsTrigger value="pricing">Pricing</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-6">
                  <div className="prose max-w-none">
                    <h3 className="text-xl font-semibold mb-4">About this SaaS</h3>
                    <p className="text-gray-600 mb-6">{product.longDescription}</p>

                    <h4 className="text-lg font-semibold mb-3">Key Benefits</h4>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-600 mr-2" />
                        Easy integration with existing systems
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-600 mr-2" />
                        Scalable architecture for growing businesses
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-600 mr-2" />
                        24/7 customer support included
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-600 mr-2" />
                        Regular updates and new features
                      </li>
                    </ul>
                  </div>
                </TabsContent>

                <TabsContent value="features" className="mt-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    {product.features.map((feature, index) => (
                      <div key={index} className="flex items-center p-3 bg-gray-50 rounded-lg">
                        <Zap className="h-5 w-5 text-blue-600 mr-3" />
                        <span className="font-medium">{feature}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="pricing" className="mt-6">
                  <div className="grid md:grid-cols-3 gap-6">
                    {product.plans.map((plan, index) => (
                      <Card key={index} className={index === 1 ? "border-blue-600 relative" : ""}>
                        {index === 1 && (
                          <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600">
                            Most Popular
                          </Badge>
                        )}
                        <CardHeader>
                          <CardTitle>{plan.name}</CardTitle>
                          <div className="text-3xl font-bold">
                            ${plan.price}
                            <span className="text-sm font-normal text-gray-600">/month</span>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2">
                            {plan.features.map((feature, featureIndex) => (
                              <li key={featureIndex} className="flex items-center text-sm">
                                <Check className="h-4 w-4 text-green-600 mr-2" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="reviews" className="mt-6">
                  <div className="space-y-4">
                    {[1, 2, 3].map((review) => (
                      <Card key={review}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center">
                              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium mr-3">
                                U{review}
                              </div>
                              <div>
                                <div className="font-medium">User {review}</div>
                                <div className="flex items-center">
                                  {[...Array(5)].map((_, i) => (
                                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                  ))}
                                </div>
                              </div>
                            </div>
                            <span className="text-sm text-gray-600">2 days ago</span>
                          </div>
                          <p className="text-gray-600">
                            Great product! Easy to integrate and excellent customer support. Highly recommend for anyone
                            looking for a reliable solution.
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="text-2xl">
                  ${product.price}
                  <span className="text-base font-normal text-gray-600">/month</span>
                </CardTitle>
                <CardDescription>Professional Plan - Most Popular</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  size="lg"
                >
                  Purchase License
                </Button>
                <Button variant="outline" className="w-full bg-transparent" size="lg">
                  <Link href={product.demo} className="w-full">
                    Try Demo
                  </Link>
                </Button>

                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-3">What's included:</h4>
                  <ul className="space-y-2">
                    {product.features.slice(0, 4).map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <Check className="h-4 w-4 text-green-600 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">30-day money back guarantee</span>
                    <Shield className="h-4 w-4 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
