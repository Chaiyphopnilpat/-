"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  Users,
  ShoppingCart,
  TrendingUp,
  MessageSquare,
  Settings,
  Download,
  ExternalLink,
  Calendar,
  DollarSign,
} from "lucide-react"
import { Header } from "@/components/header"
import Link from "next/link"

const myLicenses = [
  {
    id: 1,
    name: "AI Chatbot SaaS",
    plan: "Professional",
    status: "Active",
    expiresAt: "2024-12-31",
    price: 49,
    icon: MessageSquare,
  },
  {
    id: 2,
    name: "Analytics Tracker Pro",
    plan: "Basic",
    status: "Active",
    expiresAt: "2024-11-15",
    price: 19,
    icon: BarChart3,
  },
]

const stats = [
  {
    title: "Active Licenses",
    value: "2",
    change: "+1 this month",
    icon: ShoppingCart,
  },
  {
    title: "Total Spent",
    value: "$68",
    change: "+$49 this month",
    icon: DollarSign,
  },
  {
    title: "API Calls",
    value: "12.5K",
    change: "+2.1K this week",
    icon: TrendingUp,
  },
  {
    title: "Support Tickets",
    value: "3",
    change: "2 resolved",
    icon: Users,
  },
]

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-gray-600">Manage your SaaS licenses and monitor usage</p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                      <p className="text-xs text-green-600">{stat.change}</p>
                    </div>
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <Tabs defaultValue="licenses" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="licenses">My Licenses</TabsTrigger>
            <TabsTrigger value="usage">Usage Analytics</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="licenses" className="mt-6">
            <div className="grid gap-6">
              {myLicenses.map((license) => {
                const Icon = license.icon
                return (
                  <Card key={license.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <Icon className="h-6 w-6 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-lg">{license.name}</h3>
                            <p className="text-gray-600">{license.plan} Plan</p>
                            <div className="flex items-center gap-4 mt-2">
                              <Badge variant={license.status === "Active" ? "default" : "secondary"}>
                                {license.status}
                              </Badge>
                              <span className="text-sm text-gray-600 flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                Expires: {license.expiresAt}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl font-bold">${license.price}/mo</span>
                          <div className="flex gap-2 ml-4">
                            <Button variant="outline" size="sm">
                              <Settings className="h-4 w-4 mr-1" />
                              Manage
                            </Button>
                            <Button variant="outline" size="sm">
                              <ExternalLink className="h-4 w-4 mr-1" />
                              Access
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}

              <Card className="border-dashed border-2 border-gray-300">
                <CardContent className="p-6 text-center">
                  <ShoppingCart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Add More SaaS Solutions</h3>
                  <p className="text-gray-600 mb-4">Discover more tools to grow your business</p>
                  <Link href="/">
                    <Button>Browse Marketplace</Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="usage" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Usage Analytics</CardTitle>
                <CardDescription>Monitor your API usage and performance metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Usage analytics will appear here</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Billing History</CardTitle>
                <CardDescription>View your payment history and manage billing</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[1, 2, 3].map((invoice) => (
                    <div key={invoice} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Invoice #{invoice}001</p>
                        <p className="text-sm text-gray-600">December {invoice}, 2024</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="outline">Paid</Badge>
                        <span className="font-medium">$68.00</span>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Manage your account preferences and security</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium mb-2">Profile Information</h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Full Name</label>
                        <input type="text" className="w-full p-2 border rounded-lg" defaultValue="John Doe" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Email</label>
                        <input type="email" className="w-full p-2 border rounded-lg" defaultValue="john@example.com" />
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Notifications</h4>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input type="checkbox" className="mr-2" defaultChecked />
                        Email notifications for license renewals
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="mr-2" defaultChecked />
                        Usage alerts and warnings
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        Marketing emails and product updates
                      </label>
                    </div>
                  </div>

                  <Button>Save Changes</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
