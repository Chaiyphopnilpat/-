"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  PieChart,
  Pie,
  Tooltip,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts"
import {
  Users,
  Shield,
  Search,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Settings,
  Eye,
  Edit,
  Download,
  RefreshCw,
  Globe,
  Target,
  BarChart3,
} from "lucide-react"

// Mock data
const licenseData = [
  { name: "Active", value: 65, color: "#4ade80" },
  { name: "Inactive", value: 25, color: "#facc15" },
  { name: "Pending", value: 10, color: "#f87171" },
]

const revenueData = [
  { month: "Jan", revenue: 12000, licenses: 45 },
  { month: "Feb", revenue: 15000, licenses: 52 },
  { month: "Mar", revenue: 18000, licenses: 61 },
  { month: "Apr", revenue: 22000, licenses: 73 },
  { month: "May", revenue: 25000, licenses: 85 },
  { month: "Jun", revenue: 28000, licenses: 92 },
]

const realtimeUsers = [
  { id: 1, name: "John Doe", email: "john@example.com", status: "active", lastSeen: "2 min ago", licenses: 3 },
  { id: 2, name: "Sarah Chen", email: "sarah@example.com", status: "active", lastSeen: "5 min ago", licenses: 2 },
  { id: 3, name: "Mike Johnson", email: "mike@example.com", status: "inactive", lastSeen: "1 hour ago", licenses: 1 },
  { id: 4, name: "Emily Davis", email: "emily@example.com", status: "pending", lastSeen: "3 min ago", licenses: 0 },
]

const seoMetrics = [
  { page: "/", keywords: 45, ranking: 3.2, traffic: 12500 },
  { page: "/products", keywords: 32, ranking: 4.1, traffic: 8900 },
  { page: "/pricing", keywords: 28, ranking: 2.8, traffic: 6700 },
  { page: "/dashboard", keywords: 15, ranking: 5.2, traffic: 3400 },
]

export default function AdminDashboard() {
  const [realTimeData, setRealTimeData] = useState(realtimeUsers)
  const [isOptimizing, setIsOptimizing] = useState(false)

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData((prev) =>
        prev.map((user) => ({
          ...user,
          lastSeen: Math.random() > 0.7 ? `${Math.floor(Math.random() * 10) + 1} min ago` : user.lastSeen,
        })),
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const handleSEOOptimization = async () => {
    setIsOptimizing(true)
    // Simulate SEO optimization process
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setIsOptimizing(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            📊 SaaS Marketplace Dashboard
          </h1>
          <p className="text-gray-600">Complete control over licenses, users, and SEO optimization</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Total Licenses</p>
                  <p className="text-3xl font-bold">1,247</p>
                  <p className="text-blue-100 text-xs">+12% from last month</p>
                </div>
                <Shield className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">Active Users</p>
                  <p className="text-3xl font-bold">892</p>
                  <p className="text-green-100 text-xs">+8% from last month</p>
                </div>
                <Users className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Monthly Revenue</p>
                  <p className="text-3xl font-bold">$28K</p>
                  <p className="text-purple-100 text-xs">+15% from last month</p>
                </div>
                <TrendingUp className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">SEO Score</p>
                  <p className="text-3xl font-bold">94/100</p>
                  <p className="text-orange-100 text-xs">+3 points this week</p>
                </div>
                <Search className="h-8 w-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Tabs */}
        <Tabs defaultValue="licenses" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="licenses" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              License Control
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="seo" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              SEO Toolkit
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* License Control Tab */}
          <TabsContent value="licenses" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* License Overview Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>License Overview</CardTitle>
                  <CardDescription>Current license distribution across all SaaS products</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={licenseData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {licenseData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-center gap-4 mt-4">
                    {licenseData.map((entry, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
                        <span className="text-sm">
                          {entry.name}: {entry.value}%
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* License Management Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>License Management</CardTitle>
                  <CardDescription>Quick actions for license control</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="h-20 flex flex-col items-center justify-center">
                      <CheckCircle className="h-6 w-6 mb-2" />
                      Activate Licenses
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col items-center justify-center bg-transparent">
                      <Clock className="h-6 w-6 mb-2" />
                      Suspend Licenses
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col items-center justify-center bg-transparent">
                      <RefreshCw className="h-6 w-6 mb-2" />
                      Renew Licenses
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col items-center justify-center bg-transparent">
                      <Download className="h-6 w-6 mb-2" />
                      Export Report
                    </Button>
                  </div>

                  <div className="pt-4 border-t">
                    <Label htmlFor="bulk-action">Bulk License Action</Label>
                    <div className="flex gap-2 mt-2">
                      <Input placeholder="Enter license IDs (comma separated)" />
                      <Button>Apply</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent License Activities */}
            <Card>
              <CardHeader>
                <CardTitle>Recent License Activities</CardTitle>
                <CardDescription>Latest license changes and updates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      user: "john@example.com",
                      action: "License Activated",
                      product: "AI Chatbot SaaS",
                      time: "2 min ago",
                      status: "success",
                    },
                    {
                      user: "sarah@example.com",
                      action: "License Renewed",
                      product: "Analytics Pro",
                      time: "5 min ago",
                      status: "success",
                    },
                    {
                      user: "mike@example.com",
                      action: "License Suspended",
                      product: "CRM Lite",
                      time: "10 min ago",
                      status: "warning",
                    },
                    {
                      user: "emily@example.com",
                      action: "License Expired",
                      product: "SEO Toolkit",
                      time: "15 min ago",
                      status: "error",
                    },
                  ].map((activity, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            activity.status === "success"
                              ? "bg-green-500"
                              : activity.status === "warning"
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                        />
                        <div>
                          <p className="font-medium">{activity.action}</p>
                          <p className="text-sm text-gray-600">
                            {activity.user} • {activity.product}
                          </p>
                        </div>
                      </div>
                      <span className="text-sm text-gray-500">{activity.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Real-time User Monitoring
                </CardTitle>
                <CardDescription>✅ ระบบตรวจจับผู้ใช้งาน / สิทธิ์แบบเรียลไทม์</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-sm font-medium">Live Updates Active</span>
                  </div>
                  <Button variant="outline" size="sm">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>
                </div>

                <div className="space-y-3">
                  {realTimeData.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 bg-white rounded-lg border">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-3 h-3 rounded-full ${
                            user.status === "active"
                              ? "bg-green-500"
                              : user.status === "pending"
                                ? "bg-yellow-500"
                                : "bg-gray-400"
                          }`}
                        />
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-600">{user.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant={user.status === "active" ? "default" : "secondary"}>
                          {user.licenses} licenses
                        </Badge>
                        <span className="text-sm text-gray-500">{user.lastSeen}</span>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Settings className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* User Management Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Manage Users</h3>
                  <p className="text-sm text-gray-600 mb-4">Add, edit, or remove user accounts</p>
                  <Button className="w-full">Manage Users</Button>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <Shield className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Permission Control</h3>
                  <p className="text-sm text-gray-600 mb-4">Set user roles and permissions</p>
                  <Button variant="outline" className="w-full bg-transparent">
                    Set Permissions
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <AlertCircle className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Security Alerts</h3>
                  <p className="text-sm text-gray-600 mb-4">Monitor suspicious activities</p>
                  <Button variant="outline" className="w-full bg-transparent">
                    View Alerts
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* SEO Toolkit Tab */}
          <TabsContent value="seo" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  SEO Optimization Toolkit
                </CardTitle>
                <CardDescription>🔍 ระบบช่วยปรับ Meta / URL / Keyword แบบอัตโนมัติ</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Auto Optimization */}
                  <div className="space-y-4">
                    <h4 className="font-semibold">Automatic SEO Optimization</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4 text-blue-600" />
                          <span>Meta Tags Optimization</span>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <Target className="h-4 w-4 text-green-600" />
                          <span>Keyword Auto-Detection</span>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-purple-600" />
                          <span>URL Structure Optimization</span>
                        </div>
                        <Switch />
                      </div>
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      onClick={handleSEOOptimization}
                      disabled={isOptimizing}
                    >
                      {isOptimizing ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Optimizing...
                        </>
                      ) : (
                        <>
                          <Search className="h-4 w-4 mr-2" />
                          Optimize Now
                        </>
                      )}
                    </Button>
                  </div>

                  {/* SEO Metrics */}
                  <div className="space-y-4">
                    <h4 className="font-semibold">Current SEO Performance</h4>
                    <div className="space-y-3">
                      {seoMetrics.map((metric, index) => (
                        <div key={index} className="p-3 bg-white border rounded-lg">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium">{metric.page}</span>
                            <Badge variant="outline">{metric.keywords} keywords</Badge>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Avg. Ranking:</span>
                              <span className="ml-2 font-medium">{metric.ranking}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Traffic:</span>
                              <span className="ml-2 font-medium">{metric.traffic.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* SEO Tools Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <Target className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Keyword Research</h3>
                  <p className="text-sm text-gray-600 mb-4">Find high-impact keywords for your SaaS</p>
                  <Button variant="outline" className="w-full bg-transparent">
                    Research Keywords
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <Globe className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Site Audit</h3>
                  <p className="text-sm text-gray-600 mb-4">Comprehensive SEO health check</p>
                  <Button variant="outline" className="w-full bg-transparent">
                    Run Audit
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <TrendingUp className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Rank Tracking</h3>
                  <p className="text-sm text-gray-600 mb-4">Monitor keyword rankings</p>
                  <Button variant="outline" className="w-full bg-transparent">
                    Track Rankings
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Revenue Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Revenue & License Growth</CardTitle>
                  <CardDescription>Monthly performance overview</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={revenueData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="revenue" fill="#3b82f6" />
                        <Bar dataKey="licenses" fill="#10b981" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* User Growth Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>User Growth Trend</CardTitle>
                  <CardDescription>Active users over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={revenueData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="licenses" stroke="#8b5cf6" strokeWidth={3} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Performance Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>Key performance indicators for your SaaS marketplace</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">94.2%</div>
                    <div className="text-sm text-gray-600">Customer Satisfaction</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">$1.2M</div>
                    <div className="text-sm text-gray-600">Annual Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">2.3x</div>
                    <div className="text-sm text-gray-600">Growth Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-orange-600">99.9%</div>
                    <div className="text-sm text-gray-600">Uptime</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
