"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Users, Shield, Plus, Edit, Trash2, Search, Crown, Settings, Eye } from "lucide-react"
import { RBACManager } from "@/lib/rbac/rbac-manager"
import type { Role, Permission } from "@/lib/rbac/types"
import { RoleBadge } from "@/components/rbac/role-badge"
import { ProtectedRoute } from "@/components/rbac/protected-route"

// Mock user data with roles
const mockUsers = [
  { id: "1", name: "John Doe", email: "john@example.com", roles: ["admin", "manager"] },
  { id: "2", name: "Sarah Chen", email: "sarah@example.com", roles: ["manager"] },
  { id: "3", name: "Mike Johnson", email: "mike@example.com", roles: ["support"] },
  { id: "4", name: "Emily Davis", email: "emily@example.com", roles: ["analyst"] },
  { id: "5", name: "Alex Wilson", email: "alex@example.com", roles: ["user"] },
]

export default function RoleManagementPage() {
  const [roles, setRoles] = useState<Role[]>([])
  const [permissions, setPermissions] = useState<Permission[]>([])
  const [selectedRole, setSelectedRole] = useState<Role | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreating, setIsCreating] = useState(false)

  useEffect(() => {
    setRoles(RBACManager.getAllRoles())
    setPermissions(RBACManager.getAllPermissions())
  }, [])

  const filteredRoles = roles.filter(
    (role) =>
      role.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      role.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const permissionsByCategory = permissions.reduce(
    (acc, permission) => {
      if (!acc[permission.category]) {
        acc[permission.category] = []
      }
      acc[permission.category].push(permission)
      return acc
    },
    {} as Record<string, Permission[]>,
  )

  const getUsersWithRole = (roleId: string) => {
    return mockUsers.filter((user) => user.roles.includes(roleId))
  }

  return (
    <ProtectedRoute requiredPermissions={["users.roles.assign", "system.settings.read"]}>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
              🛡️ Role-Based Access Control
            </h1>
            <p className="text-gray-600">Manage user roles, permissions, and access control</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Roles</p>
                    <p className="text-3xl font-bold">{roles.length}</p>
                  </div>
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Permissions</p>
                    <p className="text-3xl font-bold">{permissions.length}</p>
                  </div>
                  <Settings className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Active Users</p>
                    <p className="text-3xl font-bold">{mockUsers.length}</p>
                  </div>
                  <Users className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">System Roles</p>
                    <p className="text-3xl font-bold">{roles.filter((r) => r.isSystem).length}</p>
                  </div>
                  <Crown className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="roles" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="roles">Roles Management</TabsTrigger>
              <TabsTrigger value="permissions">Permissions</TabsTrigger>
              <TabsTrigger value="assignments">User Assignments</TabsTrigger>
              <TabsTrigger value="audit">Audit Log</TabsTrigger>
            </TabsList>

            {/* Roles Management */}
            <TabsContent value="roles" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>System Roles</CardTitle>
                      <CardDescription>Manage roles and their permissions</CardDescription>
                    </div>
                    <Button className="gap-2">
                      <Plus className="h-4 w-4" />
                      Create Role
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-6">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        placeholder="Search roles..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="grid gap-4">
                    {filteredRoles.map((role) => (
                      <Card key={role.id} className="border-l-4" style={{ borderLeftColor: role.color }}>
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <RoleBadge role={role} size="lg" />
                              <div>
                                <h3 className="font-semibold text-lg">{role.name}</h3>
                                <p className="text-gray-600">{role.description}</p>
                                <div className="flex items-center gap-4 mt-2">
                                  <Badge variant="outline">Level {role.level}</Badge>
                                  <Badge variant="outline">{role.permissions.length} permissions</Badge>
                                  <Badge variant="outline">{getUsersWithRole(role.id).length} users</Badge>
                                  {role.isSystem && <Badge variant="secondary">System Role</Badge>}
                                </div>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" onClick={() => setSelectedRole(role)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="sm" disabled={role.isSystem}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                disabled={role.isSystem}
                                className="text-red-600 bg-transparent"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Role Details Modal */}
              {selectedRole && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <RoleBadge role={selectedRole} />
                      Role Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold mb-3">Role Information</h4>
                        <div className="space-y-2">
                          <div>
                            <strong>Name:</strong> {selectedRole.name}
                          </div>
                          <div>
                            <strong>Description:</strong> {selectedRole.description}
                          </div>
                          <div>
                            <strong>Level:</strong> {selectedRole.level}
                          </div>
                          <div>
                            <strong>System Role:</strong> {selectedRole.isSystem ? "Yes" : "No"}
                          </div>
                          <div>
                            <strong>Users:</strong> {getUsersWithRole(selectedRole.id).length}
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-3">Permissions ({selectedRole.permissions.length})</h4>
                        <div className="max-h-64 overflow-y-auto space-y-1">
                          {selectedRole.permissions.map((permissionId) => {
                            const permission = RBACManager.getPermission(permissionId)
                            return permission ? (
                              <div key={permissionId} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                                <Badge variant="outline" className="text-xs">
                                  {permission.category}
                                </Badge>
                                <span className="text-sm">{permission.name}</span>
                              </div>
                            ) : null
                          })}
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 mt-6">
                      <Button variant="outline" onClick={() => setSelectedRole(null)}>
                        Close
                      </Button>
                      <Button disabled={selectedRole.isSystem}>Edit Role</Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Permissions */}
            <TabsContent value="permissions" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>System Permissions</CardTitle>
                  <CardDescription>All available permissions organized by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {Object.entries(permissionsByCategory).map(([category, categoryPermissions]) => (
                      <div key={category}>
                        <h3 className="font-semibold text-lg mb-3 capitalize">{category} Permissions</h3>
                        <div className="grid gap-3">
                          {categoryPermissions.map((permission) => (
                            <div
                              key={permission.id}
                              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                            >
                              <div>
                                <div className="font-medium">{permission.name}</div>
                                <div className="text-sm text-gray-600">{permission.description}</div>
                                <div className="flex gap-2 mt-1">
                                  <Badge variant="outline" className="text-xs">
                                    {permission.resource}
                                  </Badge>
                                  <Badge variant="outline" className="text-xs">
                                    {permission.action}
                                  </Badge>
                                </div>
                              </div>
                              <div className="text-sm text-gray-500">
                                {roles.filter((role) => role.permissions.includes(permission.id)).length} roles
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* User Assignments */}
            <TabsContent value="assignments" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>User Role Assignments</CardTitle>
                  <CardDescription>Manage user role assignments and permissions</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Current Roles</TableHead>
                        <TableHead>Permissions Count</TableHead>
                        <TableHead>Last Updated</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mockUsers.map((user) => {
                        const userRoles = user.roles
                          .map((roleId) => roles.find((r) => r.id === roleId))
                          .filter(Boolean) as Role[]
                        const permissionCount = new Set(userRoles.flatMap((role) => role.permissions)).size

                        return (
                          <TableRow key={user.id}>
                            <TableCell>
                              <div>
                                <div className="font-medium">{user.name}</div>
                                <div className="text-sm text-gray-600">{user.email}</div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1 flex-wrap">
                                {userRoles.map((role) => (
                                  <RoleBadge key={role.id} role={role} size="sm" />
                                ))}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{permissionCount} permissions</Badge>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm text-gray-600">2 days ago</span>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Audit Log */}
            <TabsContent value="audit" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Access Control Audit Log</CardTitle>
                  <CardDescription>Track all role and permission changes</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        action: "Role Assigned",
                        user: "john@example.com",
                        details: "Admin role assigned by super_admin",
                        time: "2 hours ago",
                        type: "success",
                      },
                      {
                        action: "Permission Denied",
                        user: "sarah@example.com",
                        details: "Attempted to access system.settings.write",
                        time: "4 hours ago",
                        type: "warning",
                      },
                      {
                        action: "Role Modified",
                        user: "mike@example.com",
                        details: "Support role permissions updated",
                        time: "1 day ago",
                        type: "info",
                      },
                      {
                        action: "Access Granted",
                        user: "emily@example.com",
                        details: "Analytics dashboard accessed",
                        time: "1 day ago",
                        type: "success",
                      },
                      {
                        action: "Role Removed",
                        user: "alex@example.com",
                        details: "Manager role removed by admin",
                        time: "2 days ago",
                        type: "error",
                      },
                    ].map((log, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-2 h-2 rounded-full ${
                              log.type === "success"
                                ? "bg-green-500"
                                : log.type === "warning"
                                  ? "bg-yellow-500"
                                  : log.type === "error"
                                    ? "bg-red-500"
                                    : "bg-blue-500"
                            }`}
                          />
                          <div>
                            <div className="font-medium">{log.action}</div>
                            <div className="text-sm text-gray-600">
                              {log.user} • {log.details}
                            </div>
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">{log.time}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  )
}
