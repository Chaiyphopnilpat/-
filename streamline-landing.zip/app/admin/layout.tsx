import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Admin Dashboard - SaaS Marketplace",
  description: "Complete control over licenses, users, and SEO optimization",
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">{children}</div>
}
