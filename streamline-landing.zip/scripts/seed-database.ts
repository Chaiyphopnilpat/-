import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function main() {
  // Seed products
  const products = [
    {
      name: "AI Chatbot SaaS",
      description: "Embeddable AI assistant with custom training",
      longDescription:
        "Transform your customer support with our advanced AI chatbot. Features include natural language processing, custom training on your data, multi-language support, and seamless integration with popular platforms.",
      price: 49,
      category: "AI & Automation",
      rating: 4.8,
      users: 1200,
      features: [
        "Custom AI Training",
        "Multi-language Support",
        "Real-time Analytics",
        "API Access",
        "White-label Solution",
        "24/7 Support",
      ],
      images: ["/placeholder.svg?height=400&width=600&text=AI+Chatbot+Dashboard"],
      demoUrl: "/demo/chatbot",
      docsUrl: "/docs/chatbot",
    },
    {
      name: "Analytics Tracker Pro",
      description: "Advanced analytics SDK with real-time insights",
      longDescription:
        "Get deep insights into your application performance with our comprehensive analytics platform. Track user behavior, monitor performance metrics, and make data-driven decisions.",
      price: 29,
      category: "Analytics",
      rating: 4.6,
      users: 850,
      features: [
        "Real-time Data Processing",
        "Custom Dashboards",
        "Export Tools",
        "Team Collaboration",
        "API Integration",
        "Mobile Analytics",
      ],
      images: ["/placeholder.svg?height=400&width=600&text=Analytics+Dashboard"],
      demoUrl: "/demo/analytics",
      docsUrl: "/docs/analytics",
    },
    {
      name: "CRM Lite Enterprise",
      description: "Lightweight CRM with powerful workflow automation",
      longDescription:
        "Streamline your sales process with our intuitive CRM system. Manage leads, automate workflows, and close more deals with powerful automation features.",
      price: 79,
      category: "CRM & Sales",
      rating: 4.9,
      users: 2100,
      features: [
        "Lead Management",
        "Workflow Automation",
        "Third-party Integrations",
        "Mobile App",
        "Sales Pipeline",
        "Reporting & Analytics",
      ],
      images: ["/placeholder.svg?height=400&width=600&text=CRM+Dashboard"],
      demoUrl: "/demo/crm",
      docsUrl: "/docs/crm",
    },
  ]

  for (const product of products) {
    await prisma.product.upsert({
      where: { name: product.name },
      update: product,
      create: product,
    })
  }

  console.log("Database seeded successfully!")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
