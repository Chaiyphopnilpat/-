"use client"

import type React from "react"

import { useState, useEffect, useContext, createContext } from "react"
import { RBACManager } from "@/lib/rbac/rbac-manager"
import type { Role, Permission, AccessContext } from "@/lib/rbac/types"

interface RBACContextType {
  context: AccessContext | null
  roles: Role[]
  permissions: Permission[]
  hasPermission: (permissionId: string) => boolean
  hasAnyPermission: (permissionIds: string[]) => boolean
  hasAllPermissions: (permissionIds: string[]) => boolean
  canAccessResource: (resource: string, action: string) => boolean
  isLoading: boolean
}

const RBACContext = createContext<RBACContextType | null>(null)

export function RBACProvider({
  children,
  userId,
}: {
  children: React.ReactNode
  userId: string
}) {
  const [context, setContext] = useState<AccessContext | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (userId) {
      // Create access context
      const accessContext = RBACManager.createAccessContext(
        userId,
        `session-${Date.now()}`,
        window.location.hostname,
        navigator.userAgent,
      )

      setContext(accessContext)
      setIsLoading(false)
    }
  }, [userId])

  const hasPermission = (permissionId: string): boolean => {
    if (!context) return false
    return RBACManager.hasPermission(context.userId, permissionId)
  }

  const hasAnyPermission = (permissionIds: string[]): boolean => {
    if (!context) return false
    return RBACManager.hasAnyPermission(context.userId, permissionIds)
  }

  const hasAllPermissions = (permissionIds: string[]): boolean => {
    if (!context) return false
    return RBACManager.hasAllPermissions(context.userId, permissionIds)
  }

  const canAccessResource = (resource: string, action: string): boolean => {
    if (!context) return false
    return RBACManager.canAccessResource(context.userId, resource, action)
  }

  const value: RBACContextType = {
    context,
    roles: context?.roles || [],
    permissions: context?.permissions || [],
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    canAccessResource,
    isLoading,
  }

  return <RBACContext.Provider value={value}>{children}</RBACContext.Provider>
}

export function useRBAC(): RBACContextType {
  const context = useContext(RBACContext)
  if (!context) {
    throw new Error("useRBAC must be used within an RBACProvider")
  }
  return context
}
