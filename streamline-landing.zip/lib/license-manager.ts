export interface License {
  id: string
  key: string
  productId: string
  productName: string
  customerEmail: string
  customerId: string
  status: "active" | "expired" | "suspended" | "pending"
  plan: "basic" | "professional" | "enterprise"
  expiresAt: Date
  createdAt: Date
  updatedAt: Date
  usageCount: number
  maxUsage: number
  features: string[]
  metadata?: Record<string, any>
}

export interface LicenseValidationResult {
  isValid: boolean
  license?: License
  reason?: string
  remainingUsage?: number
  daysUntilExpiry?: number
}

export class LicenseManager {
  private static licenses: Map<string, License> = new Map()

  static generateLicenseKey(productId: string, plan: string): string {
    const timestamp = Date.now().toString(36).toUpperCase()
    const random = Math.random().toString(36).substr(2, 6).toUpperCase()
    const planCode = plan.substring(0, 3).toUpperCase()
    return `SAAS-${new Date().getFullYear()}-${planCode}-${timestamp}-${random}`
  }

  static async createLicense(data: {
    productId: string
    productName: string
    customerEmail: string
    customerId: string
    plan: License["plan"]
    durationMonths: number
    maxUsage: number
    features: string[]
  }): Promise<License> {
    const license: License = {
      id: crypto.randomUUID(),
      key: this.generateLicenseKey(data.productId, data.plan),
      productId: data.productId,
      productName: data.productName,
      customerEmail: data.customerEmail,
      customerId: data.customerId,
      status: "active",
      plan: data.plan,
      expiresAt: new Date(Date.now() + data.durationMonths * 30 * 24 * 60 * 60 * 1000),
      createdAt: new Date(),
      updatedAt: new Date(),
      usageCount: 0,
      maxUsage: data.maxUsage,
      features: data.features,
    }

    this.licenses.set(license.key, license)
    return license
  }

  static async validateLicense(licenseKey: string): Promise<LicenseValidationResult> {
    const license = this.licenses.get(licenseKey)

    if (!license) {
      return {
        isValid: false,
        reason: "License key not found",
      }
    }

    const now = new Date()
    const isExpired = now > license.expiresAt
    const isOverUsage = license.usageCount >= license.maxUsage
    const isSuspended = license.status === "suspended"

    if (isExpired) {
      return {
        isValid: false,
        license,
        reason: "License has expired",
        daysUntilExpiry: 0,
      }
    }

    if (isOverUsage) {
      return {
        isValid: false,
        license,
        reason: "Usage limit exceeded",
        remainingUsage: 0,
      }
    }

    if (isSuspended) {
      return {
        isValid: false,
        license,
        reason: "License is suspended",
      }
    }

    const daysUntilExpiry = Math.ceil((license.expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    const remainingUsage = license.maxUsage - license.usageCount

    return {
      isValid: true,
      license,
      remainingUsage,
      daysUntilExpiry,
    }
  }

  static async incrementUsage(licenseKey: string, amount = 1): Promise<boolean> {
    const license = this.licenses.get(licenseKey)
    if (!license) return false

    license.usageCount += amount
    license.updatedAt = new Date()
    this.licenses.set(licenseKey, license)

    return true
  }

  static async suspendLicense(licenseKey: string): Promise<boolean> {
    const license = this.licenses.get(licenseKey)
    if (!license) return false

    license.status = "suspended"
    license.updatedAt = new Date()
    this.licenses.set(licenseKey, license)

    return true
  }

  static async activateLicense(licenseKey: string): Promise<boolean> {
    const license = this.licenses.get(licenseKey)
    if (!license) return false

    license.status = "active"
    license.updatedAt = new Date()
    this.licenses.set(licenseKey, license)

    return true
  }

  static async renewLicense(licenseKey: string, additionalMonths: number): Promise<boolean> {
    const license = this.licenses.get(licenseKey)
    if (!license) return false

    const currentExpiry = license.expiresAt.getTime()
    const additionalTime = additionalMonths * 30 * 24 * 60 * 60 * 1000
    license.expiresAt = new Date(currentExpiry + additionalTime)
    license.updatedAt = new Date()
    this.licenses.set(licenseKey, license)

    return true
  }

  static getAllLicenses(): License[] {
    return Array.from(this.licenses.values())
  }

  static getLicensesByCustomer(customerEmail: string): License[] {
    return Array.from(this.licenses.values()).filter((license) => license.customerEmail === customerEmail)
  }

  static getLicensesByStatus(status: License["status"]): License[] {
    return Array.from(this.licenses.values()).filter((license) => license.status === status)
  }

  static getExpiringLicenses(days: number): License[] {
    const cutoffDate = new Date(Date.now() + days * 24 * 60 * 60 * 1000)
    return Array.from(this.licenses.values()).filter(
      (license) => license.expiresAt <= cutoffDate && license.status === "active",
    )
  }
}
