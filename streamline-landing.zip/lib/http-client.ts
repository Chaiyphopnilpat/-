interface HttpClientOptions {
  baseURL?: string
  timeout?: number
  defaultHeaders?: Record<string, string>
}

interface RequestOptions {
  method: string
  url: string
  headers?: Record<string, string>
  body?: string
  timeout?: number
}

interface ResponseMetrics {
  responseTime: number
  size: number
  timestamp: Date
}

export class HttpClient {
  private baseURL: string
  private defaultHeaders: Record<string, string>
  private timeout: number

  constructor(options: HttpClientOptions = {}) {
    this.baseURL = options.baseURL || ""
    this.defaultHeaders = options.defaultHeaders || {}
    this.timeout = options.timeout || 30000
  }

  async request(options: RequestOptions): Promise<{
    response: Response
    metrics: ResponseMetrics
  }> {
    const startTime = Date.now()
    const url = this.baseURL + options.url

    const headers = {
      ...this.defaultHeaders,
      ...options.headers,
    }

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), options.timeout || this.timeout)

    try {
      const response = await fetch(url, {
        method: options.method,
        headers,
        body: options.body,
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      const responseTime = Date.now() - startTime
      const responseText = await response.clone().text()
      const size = new Blob([responseText]).size

      return {
        response,
        metrics: {
          responseTime,
          size,
          timestamp: new Date(),
        },
      }
    } catch (error) {
      clearTimeout(timeoutId)
      throw error
    }
  }

  async get(url: string, headers?: Record<string, string>) {
    return this.request({ method: "GET", url, headers })
  }

  async post(url: string, body?: string, headers?: Record<string, string>) {
    return this.request({ method: "POST", url, body, headers })
  }

  async put(url: string, body?: string, headers?: Record<string, string>) {
    return this.request({ method: "PUT", url, body, headers })
  }

  async patch(url: string, body?: string, headers?: Record<string, string>) {
    return this.request({ method: "PATCH", url, body, headers })
  }

  async delete(url: string, headers?: Record<string, string>) {
    return this.request({ method: "DELETE", url, headers })
  }

  async head(url: string, headers?: Record<string, string>) {
    return this.request({ method: "HEAD", url, headers })
  }

  async options(url: string, headers?: Record<string, string>) {
    return this.request({ method: "OPTIONS", url, headers })
  }
}
