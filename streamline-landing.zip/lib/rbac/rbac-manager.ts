import type { Permission, Role, UserRole, AccessContext } from "./types"
import { PERMISSIONS } from "./permissions"
import { SYSTEM_ROLES } from "./roles"

export class RBACManager {
  private static permissions: Map<string, Permission> = new Map()
  private static roles: Map<string, Role> = new Map()
  private static userRoles: Map<string, UserRole[]> = new Map()

  static initialize() {
    // Load permissions
    PERMISSIONS.forEach((permission) => {
      this.permissions.set(permission.id, permission)
    })

    // Load system roles
    SYSTEM_ROLES.forEach((role) => {
      this.roles.set(role.id, role)
    })
  }

  static getPermission(permissionId: string): Permission | undefined {
    return this.permissions.get(permissionId)
  }

  static getRole(roleId: string): Role | undefined {
    return this.roles.get(roleId)
  }

  static getAllRoles(): Role[] {
    return Array.from(this.roles.values()).sort((a, b) => b.level - a.level)
  }

  static getAllPermissions(): Permission[] {
    return Array.from(this.permissions.values())
  }

  static getPermissionsByCategory(category: Permission["category"]): Permission[] {
    return Array.from(this.permissions.values()).filter((p) => p.category === category)
  }

  static assignUserRole(userId: string, roleId: string, assignedBy: string, expiresAt?: Date): boolean {
    const role = this.getRole(roleId)
    if (!role) return false

    const userRoles = this.userRoles.get(userId) || []

    // Check if user already has this role
    const existingRole = userRoles.find((ur) => ur.roleId === roleId && ur.isActive)
    if (existingRole) return false

    const userRole: UserRole = {
      userId,
      roleId,
      assignedBy,
      assignedAt: new Date(),
      expiresAt,
      isActive: true,
    }

    userRoles.push(userRole)
    this.userRoles.set(userId, userRoles)

    return true
  }

  static removeUserRole(userId: string, roleId: string): boolean {
    const userRoles = this.userRoles.get(userId) || []
    const roleIndex = userRoles.findIndex((ur) => ur.roleId === roleId && ur.isActive)

    if (roleIndex === -1) return false

    userRoles[roleIndex].isActive = false
    this.userRoles.set(userId, userRoles)

    return true
  }

  static getUserRoles(userId: string): Role[] {
    const userRoles = this.userRoles.get(userId) || []
    const activeRoles = userRoles.filter((ur) => {
      if (!ur.isActive) return false
      if (ur.expiresAt && ur.expiresAt < new Date()) {
        ur.isActive = false
        return false
      }
      return true
    })

    return activeRoles
      .map((ur) => this.getRole(ur.roleId))
      .filter((role): role is Role => role !== undefined)
      .sort((a, b) => b.level - a.level)
  }

  static getUserPermissions(userId: string): Permission[] {
    const roles = this.getUserRoles(userId)
    const permissionIds = new Set<string>()

    roles.forEach((role) => {
      role.permissions.forEach((permissionId) => {
        permissionIds.add(permissionId)
      })
    })

    return Array.from(permissionIds)
      .map((id) => this.getPermission(id))
      .filter((permission): permission is Permission => permission !== undefined)
  }

  static hasPermission(userId: string, permissionId: string): boolean {
    const userPermissions = this.getUserPermissions(userId)
    return userPermissions.some((p) => p.id === permissionId)
  }

  static hasAnyPermission(userId: string, permissionIds: string[]): boolean {
    return permissionIds.some((permissionId) => this.hasPermission(userId, permissionId))
  }

  static hasAllPermissions(userId: string, permissionIds: string[]): boolean {
    return permissionIds.every((permissionId) => this.hasPermission(userId, permissionId))
  }

  static canAccessResource(userId: string, resource: string, action: string): boolean {
    const userPermissions = this.getUserPermissions(userId)
    return userPermissions.some(
      (p) => (p.resource === resource && p.action === action) || (p.resource === "system" && p.action === "admin"),
    )
  }

  static getHighestRole(userId: string): Role | null {
    const roles = this.getUserRoles(userId)
    return roles.length > 0 ? roles[0] : null
  }

  static createAccessContext(userId: string, sessionId: string, ipAddress?: string, userAgent?: string): AccessContext {
    return {
      userId,
      roles: this.getUserRoles(userId),
      permissions: this.getUserPermissions(userId),
      sessionId,
      ipAddress,
      userAgent,
    }
  }

  static logAccess(context: AccessContext, resource: string, action: string, success: boolean) {
    // Log access attempt for audit purposes
    console.log(`Access Log: ${context.userId} attempted ${action} on ${resource} - ${success ? "SUCCESS" : "DENIED"}`)
  }
}

// Initialize the RBAC system
RBACManager.initialize()
