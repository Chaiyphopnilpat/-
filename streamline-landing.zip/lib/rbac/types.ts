export interface Permission {
  id: string
  name: string
  description: string
  resource: string
  action: string
  category: "system" | "user" | "license" | "product" | "analytics" | "seo"
}

export interface Role {
  id: string
  name: string
  description: string
  level: number
  permissions: string[]
  isSystem: boolean
  color: string
  icon: string
  createdAt: Date
  updatedAt: Date
}

export interface UserRole {
  userId: string
  roleId: string
  assignedBy: string
  assignedAt: Date
  expiresAt?: Date
  isActive: boolean
}

export interface RoleHierarchy {
  parentRole: string
  childRole: string
  inheritPermissions: boolean
}

export interface AccessContext {
  userId: string
  roles: Role[]
  permissions: Permission[]
  sessionId: string
  ipAddress?: string
  userAgent?: string
}
