interface UserActivity {
  userId: string
  action: string
  timestamp: Date
  metadata?: Record<string, any>
}

export class RealtimeMonitor {
  private static activities: UserActivity[] = []

  static trackActivity(activity: UserActivity) {
    this.activities.unshift(activity)
    // Keep only last 100 activities
    if (this.activities.length > 100) {
      this.activities = this.activities.slice(0, 100)
    }
  }

  static getRecentActivities(limit = 10): UserActivity[] {
    return this.activities.slice(0, limit)
  }

  static getUserStatus(userId: string): "active" | "inactive" | "pending" {
    const recentActivity = this.activities.find((a) => a.userId === userId)
    if (!recentActivity) return "inactive"

    const timeDiff = Date.now() - recentActivity.timestamp.getTime()
    if (timeDiff < 5 * 60 * 1000) return "active" // 5 minutes
    if (timeDiff < 60 * 60 * 1000) return "pending" // 1 hour
    return "inactive"
  }
}
