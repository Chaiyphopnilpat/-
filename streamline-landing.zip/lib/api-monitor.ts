interface ApiCall {
  id: string
  method: string
  url: string
  status: number
  responseTime: number
  timestamp: Date
  success: boolean
}

interface ApiStats {
  totalCalls: number
  successRate: number
  averageResponseTime: number
  errorRate: number
}

export class ApiMonitor {
  private calls: ApiCall[] = []
  private maxHistorySize = 1000

  logCall(call: Omit<ApiCall, "id" | "timestamp" | "success">) {
    const apiCall: ApiCall = {
      ...call,
      id: Date.now().toString(),
      timestamp: new Date(),
      success: call.status >= 200 && call.status < 300,
    }

    this.calls.unshift(apiCall)

    // Keep only recent calls
    if (this.calls.length > this.maxHistorySize) {
      this.calls = this.calls.slice(0, this.maxHistorySize)
    }
  }

  getStats(timeframe?: number): ApiStats {
    const cutoff = timeframe ? Date.now() - timeframe : 0
    const relevantCalls = this.calls.filter((call) => call.timestamp.getTime() > cutoff)

    const totalCalls = relevantCalls.length
    const successfulCalls = relevantCalls.filter((call) => call.success).length
    const totalResponseTime = relevantCalls.reduce((sum, call) => sum + call.responseTime, 0)

    return {
      totalCalls,
      successRate: totalCalls > 0 ? (successfulCalls / totalCalls) * 100 : 0,
      averageResponseTime: totalCalls > 0 ? totalResponseTime / totalCalls : 0,
      errorRate: totalCalls > 0 ? ((totalCalls - successfulCalls) / totalCalls) * 100 : 0,
    }
  }

  getRecentCalls(limit = 10): ApiCall[] {
    return this.calls.slice(0, limit)
  }

  getCallsByStatus(status: number): ApiCall[] {
    return this.calls.filter((call) => call.status === status)
  }

  getCallsByMethod(method: string): ApiCall[] {
    return this.calls.filter((call) => call.method === method)
  }

  clearHistory() {
    this.calls = []
  }
}
