"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Globe, Activity } from "lucide-react"

interface RequestHistoryProps {
  requests: Array<{
    id: string
    method: string
    url: string
    status: number
    responseTime: number
    timestamp: Date
  }>
  onSelectRequest: (request: any) => void
}

export function RequestHistory({ requests, onSelectRequest }: RequestHistoryProps) {
  const getMethodColor = (method: string) => {
    const colors = {
      GET: "bg-green-500",
      POST: "bg-blue-500",
      PUT: "bg-yellow-500",
      PATCH: "bg-orange-500",
      DELETE: "bg-red-500",
      HEAD: "bg-purple-500",
      OPTIONS: "bg-gray-500",
    }
    return colors[method as keyof typeof colors] || "bg-gray-500"
  }

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return "text-green-600"
    if (status >= 300 && status < 400) return "text-yellow-600"
    if (status >= 400 && status < 500) return "text-orange-600"
    if (status >= 500) return "text-red-600"
    return "text-gray-600"
  }

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).format(date)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Request History
        </CardTitle>
        <CardDescription>Recent API calls and responses</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {requests.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No requests yet</p>
              <p className="text-sm">Start making API calls to see history</p>
            </div>
          ) : (
            requests.map((request) => (
              <div
                key={request.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                onClick={() => onSelectRequest(request)}
              >
                <div className="flex items-center gap-3">
                  <Badge className={`${getMethodColor(request.method)} text-white text-xs`}>{request.method}</Badge>
                  <div>
                    <p className="text-sm font-medium truncate max-w-64">{request.url}</p>
                    <p className="text-xs text-gray-500">{formatTime(request.timestamp)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={`${getStatusColor(request.status)} bg-transparent border text-xs`}>
                    {request.status}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    <Clock className="h-3 w-3 mr-1" />
                    {request.responseTime}ms
                  </Badge>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
