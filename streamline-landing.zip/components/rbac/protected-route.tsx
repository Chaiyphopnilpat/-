"use client"

import type React from "react"

import { useRBAC } from "@/hooks/use-rbac"
import { AlertCircle, Lock } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredPermissions?: string[]
  requiredRoles?: string[]
  resource?: string
  action?: string
  fallback?: React.ReactNode
}

export function ProtectedRoute({
  children,
  requiredPermissions = [],
  requiredRoles = [],
  resource,
  action,
  fallback,
}: ProtectedRouteProps) {
  const { hasAllPermissions, canAccessResource, roles, isLoading } = useRBAC()

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  // Check permissions
  if (requiredPermissions.length > 0 && !hasAllPermissions(requiredPermissions)) {
    return fallback || <AccessDenied reason="Insufficient permissions" />
  }

  // Check roles
  if (requiredRoles.length > 0) {
    const hasRequiredRole = requiredRoles.some((roleId) => roles.some((role) => role.id === roleId))
    if (!hasRequiredRole) {
      return fallback || <AccessDenied reason="Required role not assigned" />
    }
  }

  // Check resource access
  if (resource && action && !canAccessResource(resource, action)) {
    return fallback || <AccessDenied reason="Resource access denied" />
  }

  return <>{children}</>
}

function AccessDenied({ reason }: { reason: string }) {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <Lock className="h-6 w-6 text-red-600" />
          </div>
          <CardTitle className="text-red-600">Access Denied</CardTitle>
          <CardDescription>{reason}</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
            <AlertCircle className="h-4 w-4" />
            Contact your administrator for access
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
