"use client"

import { Badge } from "@/components/ui/badge"
import type { Role } from "@/lib/rbac/types"
import { Crown, Shield, Users, Headphones, BarChart3, User } from "lucide-react"

interface RoleBadgeProps {
  role: Role
  size?: "sm" | "md" | "lg"
}

const iconMap = {
  Crown,
  Shield,
  Users,
  Headphones,
  BarChart3,
  User,
}

export function RoleBadge({ role, size = "md" }: RoleBadgeProps) {
  const Icon = iconMap[role.icon as keyof typeof iconMap] || User

  const sizeClasses = {
    sm: "text-xs px-2 py-1",
    md: "text-sm px-3 py-1",
    lg: "text-base px-4 py-2",
  }

  const iconSizes = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  }

  return (
    <Badge
      className={`${sizeClasses[size]} gap-1 border-0`}
      style={{
        backgroundColor: `${role.color}20`,
        color: role.color,
        border: `1px solid ${role.color}40`,
      }}
    >
      <Icon className={iconSizes[size]} />
      {role.name}
    </Badge>
  )
}
