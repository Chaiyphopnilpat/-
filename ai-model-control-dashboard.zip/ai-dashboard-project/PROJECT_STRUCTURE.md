# 📁 AI Model Control Dashboard - Project Structure

## 🏗️ Complete File Structure

```
ai-dashboard-project/
├── 📄 README.md                    # เอกสารหลักของโปรเจค
├── 📄 PROJECT_STRUCTURE.md         # ไฟล์นี้ - อธิบายโครงสร้าง
├── 🚀 start.sh                     # สคริปต์เริ่มต้นระบบ
├── 🐳 docker-compose.yml           # Docker configuration
│
├── 📁 backend/                     # Node.js + Express API
│   ├── 📄 server.js                # Main server file
│   ├── 📄 package.json             # Backend dependencies
│   ├── 📄 .env                     # Environment variables
│   ├── 📄 Dockerfile               # Docker config for backend
│   ├── 📁 models/
│   │   └── 📄 aiModel.js           # MongoDB model schema
│   └── 📁 routes/
│       └── 📄 aiModelRoutes.js     # API routes
│
└── 📁 frontend/                    # React Dashboard
    ├── 📄 package.json             # Frontend dependencies
    ├── 📄 tailwind.config.js       # Tailwind CSS config
    ├── 📄 postcss.config.js        # PostCSS config
    ├── 📄 Dockerfile               # Docker config for frontend
    ├── 📁 public/
    │   └── 📄 index.html           # Main HTML file
    └── 📁 src/
        ├── 📄 index.js             # React entry point
        ├── 📄 App.js               # Main App component
        ├── 📄 index.css            # Global styles
        ├── 📁 components/          # Reusable components
        │   ├── 📄 Header.jsx       # Top navigation
        │   ├── 📄 Sidebar.jsx      # Side navigation
        │   ├── 📄 ModelCard.jsx    # Model display card
        │   └── 📄 ModelModal.jsx   # Add/Edit modal
        ├── 📁 pages/               # Page components
        │   ├── 📄 Dashboard.jsx    # Main dashboard
        │   └── 📄 AIModels.jsx     # Models management
        ├── 📁 hooks/               # Custom React hooks
        │   └── 📄 useAIModels.js   # Models state management
        └── 📁 services/            # API services
            └── 📄 api.js           # API client
```

## 🎯 Key Components Explained

### Backend Components
- **server.js**: Express server setup with MongoDB connection
- **aiModel.js**: MongoDB schema for AI models
- **aiModelRoutes.js**: RESTful API endpoints for model management

### Frontend Components
- **App.js**: Main application with routing and layout
- **Dashboard.jsx**: Overview page with statistics and activity
- **AIModels.jsx**: Model management page with CRUD operations
- **ModelCard.jsx**: Individual model display and controls
- **ModelModal.jsx**: Form for adding/editing models
- **useAIModels.js**: Custom hook for API state management

## 🚀 Quick Start Commands

```bash
# Method 1: Using start script (Recommended)
./start.sh

# Method 2: Manual start
# Terminal 1: MongoDB
mongod

# Terminal 2: Backend
cd backend && npm install && npm run dev

# Terminal 3: Frontend  
cd frontend && npm install && npm start

# Method 3: Docker (Production)
docker-compose up -d
```

## 🔧 Configuration Files

- **.env**: Backend environment variables
- **package.json**: Dependencies and scripts
- **tailwind.config.js**: UI styling configuration
- **docker-compose.yml**: Container orchestration

## 📡 API Endpoints Summary

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/models` | Get all models |
| POST   | `/api/models` | Create new model |
| PUT    | `/api/models/:id` | Update model |
| DELETE | `/api/models/:id` | Delete model |

## 🎨 UI Features

- **Responsive Design**: Works on desktop, tablet, mobile
- **Real-time Controls**: Start/Stop/Pause models instantly
- **Parameter Tuning**: Adjust temperature, max tokens
- **Search & Filter**: Find models quickly
- **Status Monitoring**: Visual status indicators
- **Modern UI**: Clean, professional interface

## 🔮 Next Steps

1. **Install Dependencies**: Run `npm install` in both directories
2. **Setup MongoDB**: Ensure MongoDB is running
3. **Configure Environment**: Update `.env` file
4. **Start Services**: Use `./start.sh` or manual commands
5. **Access Dashboard**: Open http://localhost:3000

Happy coding! 🚀
