# ⚡ Quick Start Guide - AI Model Control Dashboard

## 🎯 ขั้นตอนการติดตั้งและใช้งาน (5 นาที)

### 1️⃣ Prerequisites
```bash
# ตรวจสอบ Node.js (ต้อง 16+)
node --version

# ตรวจสอบ npm
npm --version

# ติดตั้ง MongoDB (หากยังไม่มี)
# macOS: brew install mongodb-community
# Ubuntu: sudo apt install mongodb
# Windows: Download from mongodb.com
```

### 2️⃣ Installation
```bash
# 1. Extract โปรเจค
unzip ai-dashboard-project.zip
cd ai-dashboard-project

# 2. ติดตั้ง Backend
cd backend
npm install

# 3. ติดตั้ง Frontend  
cd ../frontend
npm install

# 4. กลับไปที่ root directory
cd ..
```

### 3️⃣ Configuration
```bash
# แก้ไขไฟล์ backend/.env (หากจำเป็น)
MONGO_URI=mongodb://localhost:27017/ai_model_control
PORT=5000
```

### 4️⃣ Start Services
```bash
# วิธีที่ 1: ใช้ start script (แนะนำ)
./start.sh

# วิธีที่ 2: Manual start
# Terminal 1: MongoDB
mongod

# Terminal 2: Backend
cd backend && npm run dev

# Terminal 3: Frontend
cd frontend && npm start
```

### 5️⃣ Access Dashboard
- 🎨 **Frontend**: http://localhost:3000
- 📡 **Backend API**: http://localhost:5000/api

## 🎮 การใช้งานพื้นฐาน

### เพิ่มโมเดลใหม่
1. คลิก "เพิ่มโมเดลใหม่" ในหน้า AI Models
2. กรอกชื่อโมเดล เช่น "GPT-4.5 Humanized"
3. ตั้งค่าพารามิเตอร์ (Temperature, Max Tokens)
4. คลิก "เพิ่มโมเดล"

### ควบคุมโมเดล
- **Start**: เริ่มการทำงานของโมเดล
- **Pause**: หยุดชั่วคราว
- **Stop**: หยุดการทำงาน
- **Settings**: ปรับพารามิเตอร์

### ดู Dashboard
- สถิติโมเดลทั้งหมด
- กิจกรรมล่าสุด
- การกระจายสถานะ

## 🐳 Docker (Alternative)
```bash
# Start with Docker
docker-compose up -d

# Stop
docker-compose down
```

## 🆘 Troubleshooting

### MongoDB ไม่เริ่มต้น
```bash
# macOS
brew services start mongodb-community

# Linux
sudo systemctl start mongod

# Windows
net start MongoDB
```

### Port ถูกใช้งาน
```bash
# ตรวจสอบ port 3000, 5000
lsof -i :3000
lsof -i :5000

# Kill process หากจำเป็น
kill -9 <PID>
```

### Dependencies Error
```bash
# ลบ node_modules และติดตั้งใหม่
rm -rf node_modules package-lock.json
npm install
```

## 📞 Support
- 📧 Email: support@example.com
- 💬 Discord: [Community Server]
- 📖 Docs: [Full Documentation]

**Happy Coding! 🚀**
