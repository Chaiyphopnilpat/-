import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  Square, 
  Settings, 
  Trash2, 
  Edit,
  Activity,
  Clock
} from 'lucide-react';

const ModelCard = ({ model, onStatusChange, onEdit, onDelete, onParametersChange }) => {
  const [showParameters, setShowParameters] = useState(false);

  const getStatusColor = (status) => {
    switch (status) {
      case 'running': return 'status-running';
      case 'paused': return 'status-paused';
      case 'stopped': return 'status-stopped';
      default: return 'status-stopped';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'running': return <Activity className="w-4 h-4" />;
      case 'paused': return <Pause className="w-4 h-4" />;
      case 'stopped': return <Square className="w-4 h-4" />;
      default: return <Square className="w-4 h-4" />;
    }
  };

  const handleStatusChange = (newStatus) => {
    onStatusChange(model._id, newStatus);
  };

  return (
    <div className="card">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">{model.name}</h3>
          <div className="flex items-center space-x-2 mb-3">
            <span className={`status-badge ${getStatusColor(model.status)}`}>
              {getStatusIcon(model.status)}
              <span className="ml-1 capitalize">{model.status}</span>
            </span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowParameters(!showParameters)}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            onClick={() => onEdit(model)}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(model._id)}
            className="p-2 text-red-400 hover:text-red-600 rounded-lg hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Control Buttons */}
      <div className="flex items-center space-x-2 mb-4">
        <button
          onClick={() => handleStatusChange('running')}
          disabled={model.status === 'running'}
          className="btn btn-success disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Play className="w-4 h-4 mr-2" />
          Start
        </button>
        <button
          onClick={() => handleStatusChange('paused')}
          disabled={model.status === 'stopped'}
          className="btn btn-warning disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Pause className="w-4 h-4 mr-2" />
          Pause
        </button>
        <button
          onClick={() => handleStatusChange('stopped')}
          disabled={model.status === 'stopped'}
          className="btn btn-danger disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Square className="w-4 h-4 mr-2" />
          Stop
        </button>
      </div>

      {/* Parameters Section */}
      {showParameters && (
        <div className="border-t border-gray-200 pt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-3">Parameters</h4>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Temperature
              </label>
              <input
                type="number"
                min="0"
                max="2"
                step="0.1"
                value={model.parameters?.temperature || 0.7}
                onChange={(e) => onParametersChange(model._id, {
                  ...model.parameters,
                  temperature: parseFloat(e.target.value)
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Max Tokens
              </label>
              <input
                type="number"
                min="1"
                max="4096"
                value={model.parameters?.maxTokens || 1024}
                onChange={(e) => onParametersChange(model._id, {
                  ...model.parameters,
                  maxTokens: parseInt(e.target.value)
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      )}

      {/* Last Updated */}
      <div className="flex items-center text-xs text-gray-500 mt-4">
        <Clock className="w-3 h-3 mr-1" />
        Last updated: {new Date(model.lastUpdated).toLocaleString('th-TH')}
      </div>
    </div>
  );
};

export default ModelCard;
