import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';

const ModelModal = ({ isOpen, onClose, onSave, model = null }) => {
  const [formData, setFormData] = useState({
    name: '',
    status: 'stopped',
    parameters: {
      temperature: 0.7,
      maxTokens: 1024,
      otherConfig: {}
    }
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (model) {
      setFormData({
        name: model.name || '',
        status: model.status || 'stopped',
        parameters: {
          temperature: model.parameters?.temperature || 0.7,
          maxTokens: model.parameters?.maxTokens || 1024,
          otherConfig: model.parameters?.otherConfig || {}
        }
      });
    } else {
      setFormData({
        name: '',
        status: 'stopped',
        parameters: {
          temperature: 0.7,
          maxTokens: 1024,
          otherConfig: {}
        }
      });
    }
    setErrors({});
  }, [model, isOpen]);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'ชื่อโมเดลจำเป็นต้องกรอก';
    }
    
    if (formData.parameters.temperature < 0 || formData.parameters.temperature > 2) {
      newErrors.temperature = 'Temperature ต้องอยู่ระหว่าง 0-2';
    }
    
    if (formData.parameters.maxTokens < 1 || formData.parameters.maxTokens > 4096) {
      newErrors.maxTokens = 'Max Tokens ต้องอยู่ระหว่าง 1-4096';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const result = await onSave(formData);
    if (result.success) {
      onClose();
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleParameterChange = (param, value) => {
    setFormData(prev => ({
      ...prev,
      parameters: {
        ...prev.parameters,
        [param]: value
      }
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md mx-4">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {model ? 'แก้ไขโมเดล' : 'เพิ่มโมเดลใหม่'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="space-y-4">
            {/* Model Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                ชื่อโมเดล *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                  errors.name ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="เช่น GPT-4.5 Humanized"
              />
              {errors.name && (
                <p className="text-red-500 text-xs mt-1">{errors.name}</p>
              )}
            </div>

            {/* Status */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                สถานะ
              </label>
              <select
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="stopped">Stopped</option>
                <option value="running">Running</option>
                <option value="paused">Paused</option>
              </select>
            </div>

            {/* Parameters */}
            <div className="border-t border-gray-200 pt-4">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Parameters</h3>
              
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">
                    Temperature (0-2)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="2"
                    step="0.1"
                    value={formData.parameters.temperature}
                    onChange={(e) => handleParameterChange('temperature', parseFloat(e.target.value))}
                    className={`w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                      errors.temperature ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.temperature && (
                    <p className="text-red-500 text-xs mt-1">{errors.temperature}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">
                    Max Tokens (1-4096)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="4096"
                    value={formData.parameters.maxTokens}
                    onChange={(e) => handleParameterChange('maxTokens', parseInt(e.target.value))}
                    className={`w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                      errors.maxTokens ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.maxTokens && (
                    <p className="text-red-500 text-xs mt-1">{errors.maxTokens}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="btn btn-primary"
            >
              {model ? 'บันทึกการแก้ไข' : 'เพิ่มโมเดล'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ModelModal;
