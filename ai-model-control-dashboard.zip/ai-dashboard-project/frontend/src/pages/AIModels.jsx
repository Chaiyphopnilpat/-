import React, { useState } from 'react';
import { Plus, Search, Filter, RefreshCw } from 'lucide-react';
import ModelCard from '../components/ModelCard';
import ModelModal from '../components/ModelModal';
import { useAIModels } from '../hooks/useAIModels';

const AIModels = () => {
  const {
    models,
    loading,
    error,
    fetchModels,
    createModel,
    updateModel,
    deleteModel,
    updateModelStatus,
    updateModelParameters,
  } = useAIModels();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingModel, setEditingModel] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Filter models based on search and status
  const filteredModels = models.filter(model => {
    const matchesSearch = model.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || model.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCreateModel = () => {
    setEditingModel(null);
    setIsModalOpen(true);
  };

  const handleEditModel = (model) => {
    setEditingModel(model);
    setIsModalOpen(true);
  };

  const handleSaveModel = async (modelData) => {
    if (editingModel) {
      return await updateModel(editingModel._id, modelData);
    } else {
      return await createModel(modelData);
    }
  };

  const handleDeleteModel = async (id) => {
    if (window.confirm('คุณแน่ใจหรือไม่ที่จะลบโมเดลนี้?')) {
      await deleteModel(id);
    }
  };

  const handleStatusChange = async (id, status) => {
    await updateModelStatus(id, status);
  };

  const handleParametersChange = async (id, parameters) => {
    await updateModelParameters(id, parameters);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin text-primary-500" />
          <span className="ml-2 text-gray-600">กำลังโหลดข้อมูล...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">AI Models</h1>
          <p className="text-gray-600">จัดการและควบคุมโมเดล AI ทั้งหมด</p>
        </div>
        <button
          onClick={handleCreateModel}
          className="btn btn-primary"
        >
          <Plus className="w-4 h-4 mr-2" />
          เพิ่มโมเดลใหม่
        </button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="ค้นหาโมเดล..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          >
            <option value="all">ทุกสถานะ</option>
            <option value="running">Running</option>
            <option value="stopped">Stopped</option>
            <option value="paused">Paused</option>
          </select>
        </div>
        <button
          onClick={fetchModels}
          className="btn bg-gray-100 text-gray-700 hover:bg-gray-200"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          รีเฟรช
        </button>
      </div>

      {/* Models Grid */}
      {filteredModels.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {models.length === 0 ? 'ยังไม่มีโมเดล' : 'ไม่พบโมเดลที่ค้นหา'}
          </h3>
          <p className="text-gray-600 mb-4">
            {models.length === 0 
              ? 'เริ่มต้นด้วยการเพิ่มโมเดล AI แรกของคุณ'
              : 'ลองเปลี่ยนคำค้นหาหรือตัวกรองสถานะ'
            }
          </p>
          {models.length === 0 && (
            <button
              onClick={handleCreateModel}
              className="btn btn-primary"
            >
              <Plus className="w-4 h-4 mr-2" />
              เพิ่มโมเดลแรก
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredModels.map((model) => (
            <ModelCard
              key={model._id}
              model={model}
              onStatusChange={handleStatusChange}
              onEdit={handleEditModel}
              onDelete={handleDeleteModel}
              onParametersChange={handleParametersChange}
            />
          ))}
        </div>
      )}

      {/* Model Modal */}
      <ModelModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveModel}
        model={editingModel}
      />
    </div>
  );
};

export default AIModels;
