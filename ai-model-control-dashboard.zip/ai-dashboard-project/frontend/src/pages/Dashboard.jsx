import React from 'react';
import { 
  Activity, 
  Bot, 
  Zap, 
  Clock,
  TrendingUp,
  Server
} from 'lucide-react';

const Dashboard = ({ models }) => {
  const runningModels = models.filter(m => m.status === 'running').length;
  const stoppedModels = models.filter(m => m.status === 'stopped').length;
  const pausedModels = models.filter(m => m.status === 'paused').length;

  const stats = [
    {
      title: 'Total Models',
      value: models.length,
      icon: Bot,
      color: 'bg-blue-500',
      change: '+12%'
    },
    {
      title: 'Running',
      value: runningModels,
      icon: Activity,
      color: 'bg-green-500',
      change: '+5%'
    },
    {
      title: 'Stopped',
      value: stoppedModels,
      icon: Server,
      color: 'bg-gray-500',
      change: '-2%'
    },
    {
      title: 'Paused',
      value: pausedModels,
      icon: Clock,
      color: 'bg-yellow-500',
      change: '+1%'
    }
  ];

  const recentActivity = [
    { action: 'Model "GPT-4.5" started', time: '2 minutes ago', type: 'success' },
    { action: 'Model "Claude-3" parameters updated', time: '5 minutes ago', type: 'info' },
    { action: 'Model "Gemini-Pro" stopped', time: '10 minutes ago', type: 'warning' },
    { action: 'New model "LLaMA-2" created', time: '15 minutes ago', type: 'success' },
  ];

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">ภาพรวมของระบบควบคุมโมเดล AI</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-600">{stat.change}</span>
                  </div>
                </div>
                <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Model Status Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Model Status Distribution</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600">Running</span>
              </div>
              <span className="text-sm font-medium text-gray-900">{runningModels}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-sm text-gray-600">Stopped</span>
              </div>
              <span className="text-sm font-medium text-gray-900">{stoppedModels}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="text-sm text-gray-600">Paused</span>
              </div>
              <span className="text-sm font-medium text-gray-900">{pausedModels}</span>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className={`w-2 h-2 rounded-full mt-2 ${
                  activity.type === 'success' ? 'bg-green-500' :
                  activity.type === 'warning' ? 'bg-yellow-500' :
                  'bg-blue-500'
                }`}></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8">
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="flex flex-wrap gap-3">
            <button className="btn btn-primary">
              <Zap className="w-4 h-4 mr-2" />
              Start All Models
            </button>
            <button className="btn btn-warning">
              <Clock className="w-4 h-4 mr-2" />
              Pause All Models
            </button>
            <button className="btn btn-danger">
              <Server className="w-4 h-4 mr-2" />
              Stop All Models
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
