import { useState, useEffect, useCallback } from 'react';
import { aiModelAPI } from '../services/api';

export const useAIModels = () => {
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // ดึงข้อมูลโมเดลทั้งหมด
  const fetchModels = useCallback(async () => {
    try {
      setLoading(true);
      const response = await aiModelAPI.getAllModels();
      setModels(response.data);
      setError(null);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch models');
    } finally {
      setLoading(false);
    }
  }, []);

  // เพิ่มโมเดลใหม่
  const createModel = async (modelData) => {
    try {
      const response = await aiModelAPI.createModel(modelData);
      setModels(prev => [...prev, response.data]);
      return { success: true, data: response.data };
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Failed to create model';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  };

  // อัปเดตโมเดล
  const updateModel = async (id, modelData) => {
    try {
      const response = await aiModelAPI.updateModel(id, modelData);
      setModels(prev => prev.map(model => 
        model._id === id ? response.data : model
      ));
      return { success: true, data: response.data };
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Failed to update model';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  };

  // ลบโมเดล
  const deleteModel = async (id) => {
    try {
      await aiModelAPI.deleteModel(id);
      setModels(prev => prev.filter(model => model._id !== id));
      return { success: true };
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Failed to delete model';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  };

  // อัปเดตสถานะโมเดล
  const updateModelStatus = async (id, status) => {
    try {
      const response = await aiModelAPI.updateModelStatus(id, status);
      setModels(prev => prev.map(model => 
        model._id === id ? response.data : model
      ));
      return { success: true, data: response.data };
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Failed to update status';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  };

  // อัปเดตพารามิเตอร์โมเดล
  const updateModelParameters = async (id, parameters) => {
    try {
      const response = await aiModelAPI.updateModelParameters(id, parameters);
      setModels(prev => prev.map(model => 
        model._id === id ? response.data : model
      ));
      return { success: true, data: response.data };
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Failed to update parameters';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  };

  useEffect(() => {
    fetchModels();
  }, [fetchModels]);

  return {
    models,
    loading,
    error,
    fetchModels,
    createModel,
    updateModel,
    deleteModel,
    updateModelStatus,
    updateModelParameters,
  };
};
