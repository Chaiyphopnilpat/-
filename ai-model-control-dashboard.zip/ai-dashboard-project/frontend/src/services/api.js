import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// AI Models API
export const aiModelAPI = {
  // ดึงโมเดลทั้งหมด
  getAllModels: () => api.get('/models'),
  
  // เพิ่มโมเดลใหม่
  createModel: (modelData) => api.post('/models', modelData),
  
  // อัปเดตโมเดล
  updateModel: (id, modelData) => api.put(`/models/${id}`, modelData),
  
  // ลบโมเดล
  deleteModel: (id) => api.delete(`/models/${id}`),
  
  // อัปเดตสถานะโมเดล
  updateModelStatus: (id, status) => 
    api.put(`/models/${id}`, { status, lastUpdated: new Date() }),
  
  // อัปเดตพารามิเตอร์โมเดล
  updateModelParameters: (id, parameters) => 
    api.put(`/models/${id}`, { parameters, lastUpdated: new Date() }),
};

export default api;
