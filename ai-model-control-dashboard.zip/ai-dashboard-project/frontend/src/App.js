import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import AIModels from './pages/AIModels';
import { useAIModels } from './hooks/useAIModels';
import './index.css';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const { models } = useAIModels();

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard models={models} />;
      case 'models':
        return <AIModels />;
      case 'analytics':
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Analytics</h1>
            <div className="card">
              <p className="text-gray-600">Analytics dashboard coming soon...</p>
            </div>
          </div>
        );
      case 'users':
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Users</h1>
            <div className="card">
              <p className="text-gray-600">User management coming soon...</p>
            </div>
          </div>
        );
      case 'settings':
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Settings</h1>
            <div className="card">
              <p className="text-gray-600">Settings panel coming soon...</p>
            </div>
          </div>
        );
      case 'help':
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Help & Support</h1>
            <div className="card">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">การใช้งานระบบ</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• ใช้หน้า Dashboard เพื่อดูภาพรวมของระบบ</li>
                    <li>• ใช้หน้า AI Models เพื่อจัดการโมเดลต่าง ๆ</li>
                    <li>• คลิกปุ่ม Start/Pause/Stop เพื่อควบคุมสถานะโมเดล</li>
                    <li>• ปรับพารามิเตอร์ได้ในแต่ละโมเดล</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">API Endpoints</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• GET /api/models - ดึงข้อมูลโมเดลทั้งหมด</li>
                    <li>• POST /api/models - เพิ่มโมเดลใหม่</li>
                    <li>• PUT /api/models/:id - อัปเดตโมเดล</li>
                    <li>• DELETE /api/models/:id - ลบโมเดล</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return <Dashboard models={models} />;
    }
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="flex-1 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;
