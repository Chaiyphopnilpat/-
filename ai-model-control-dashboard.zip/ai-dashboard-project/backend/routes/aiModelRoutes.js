const express = require('express');
const router = express.Router();
const AIModel = require('../models/aiModel');

// GET: ดึงข้อมูลโมเดลทั้งหมด
router.get('/', async (req, res) => {
  try {
    const models = await AIModel.find();
    res.json(models);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST: เพิ่มโมเดลใหม่
router.post('/', async (req, res) => {
  try {
    const model = new AIModel(req.body);
    await model.save();
    res.status(201).json(model);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// PUT: อัปเดตสถานะหรือพารามิเตอร์
router.put('/:id', async (req, res) => {
  try {
    const model = await AIModel.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!model) {
      return res.status(404).json({ error: 'Model not found' });
    }
    res.json(model);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// DELETE: ลบโมเดล
router.delete('/:id', async (req, res) => {
  try {
    const model = await AIModel.findByIdAndDelete(req.params.id);
    if (!model) {
      return res.status(404).json({ error: 'Model not found' });
    }
    res.json({ message: 'Model deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
