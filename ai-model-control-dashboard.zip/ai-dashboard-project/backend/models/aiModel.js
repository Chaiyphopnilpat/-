const mongoose = require('mongoose');

const aiModelSchema = new mongoose.Schema({
  name: String,
  status: {
    type: String,
    enum: ['running', 'stopped', 'paused'],
    default: 'stopped',
  },
  parameters: {
    temperature: Number,
    maxTokens: Number,
    otherConfig: Object,
  },
  lastUpdated: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('AIModel', aiModelSchema);
