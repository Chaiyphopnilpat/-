# 🤖 AI Model Control Dashboard

ระบบควบคุมและจัดการโมเดล AI แบบ Real-time ที่สร้างด้วย **Node.js + Express + MongoDB** สำหรับ Backend และ **React + Tailwind CSS** สำหรับ Frontend

## ✨ Features

### 🎯 Core Features
- **Dashboard Overview** - ภาพรวมสถานะโมเดลทั้งหมด
- **Model Management** - เพิ่ม/แก้ไข/ลบโมเดล AI
- **Real-time Control** - Start/Pause/Stop โมเดลแบบ Real-time
- **Parameter Tuning** - ปรับพารามิเตอร์ (Temperature, Max Tokens)
- **Status Monitoring** - ติดตามสถานะและกิจกรรมล่าสุด

### 🔧 Technical Features
- **RESTful API** - API ที่สมบูรณ์สำหรับจัดการโมเดล
- **Responsive Design** - ใช้งานได้ทุกอุปกรณ์
- **Error Handling** - จัดการข้อผิดพลาดอย่างครบถ้วน
- **Real-time Updates** - อัปเดตข้อมูลแบบ Real-time

## 🏗️ Architecture

```
ai-dashboard-project/
├── backend/                 # Node.js + Express API
│   ├── models/             # MongoDB Models
│   ├── routes/             # API Routes
│   ├── server.js           # Main Server
│   └── package.json
└── frontend/               # React Dashboard
    ├── src/
    │   ├── components/     # React Components
    │   ├── pages/          # Page Components
    │   ├── hooks/          # Custom Hooks
    │   ├── services/       # API Services
    │   └── App.js
    └── package.json
```

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ 
- MongoDB 4.4+
- npm หรือ yarn

### 1. Clone & Install

```bash
# Clone repository
git clone <repository-url>
cd ai-dashboard-project

# Install Backend Dependencies
cd backend
npm install

# Install Frontend Dependencies
cd ../frontend
npm install
```

### 2. Environment Setup

```bash
# Backend (.env)
cd backend
cp .env.example .env

# แก้ไขค่าใน .env
MONGO_URI=mongodb://localhost:27017/ai_model_control
PORT=5000
JWT_SECRET=your_jwt_secret_key_here
```

### 3. Start Services

```bash
# Terminal 1: Start MongoDB
mongod

# Terminal 2: Start Backend
cd backend
npm run dev

# Terminal 3: Start Frontend
cd frontend
npm start
```

### 4. Access Dashboard
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000/api

## 📡 API Endpoints

### Models Management
```http
GET    /api/models          # ดึงโมเดลทั้งหมด
POST   /api/models          # เพิ่มโมเดลใหม่
PUT    /api/models/:id      # อัปเดตโมเดล
DELETE /api/models/:id      # ลบโมเดล
```

### Example Request
```json
POST /api/models
{
  "name": "GPT-4.5 Humanized",
  "status": "running",
  "parameters": {
    "temperature": 0.7,
    "maxTokens": 1024,
    "otherConfig": {
      "promptStyle": "conversational"
    }
  }
}
```

## 🎨 UI Components

### Dashboard
- **Stats Cards** - แสดงสถิติโมเดลแบบ Real-time
- **Activity Feed** - กิจกรรมล่าสุดของระบบ
- **Quick Actions** - ปุ่มควบคุมด่วน

### AI Models Page
- **Model Cards** - แสดงข้อมูลโมเดลแต่ละตัว
- **Control Buttons** - Start/Pause/Stop
- **Parameter Editor** - ปรับค่าพารามิเตอร์
- **Search & Filter** - ค้นหาและกรองโมเดล

## 🔧 Development

### Backend Development
```bash
cd backend
npm run dev          # Start with nodemon
npm start           # Production start
```

### Frontend Development
```bash
cd frontend
npm start           # Development server
npm run build       # Production build
npm test            # Run tests
```

### Database Schema
```javascript
// AI Model Schema
{
  name: String,
  status: ['running', 'stopped', 'paused'],
  parameters: {
    temperature: Number,
    maxTokens: Number,
    otherConfig: Object
  },
  lastUpdated: Date
}
```

## 🚀 Deployment

### Backend Deployment
```bash
# Production Environment
NODE_ENV=production
MONGO_URI=mongodb://your-production-db
PORT=5000

# Start
npm start
```

### Frontend Deployment
```bash
# Build for production
npm run build

# Deploy to your hosting service
# (Vercel, Netlify, AWS S3, etc.)
```

## 🔮 Future Enhancements

### Phase 2 Features
- [ ] **WebSocket Integration** - Real-time updates
- [ ] **User Authentication** - JWT-based auth
- [ ] **Role-based Access** - Admin/User roles
- [ ] **Model Analytics** - Performance metrics
- [ ] **Batch Operations** - Multiple model control

### Phase 3 Features
- [ ] **Docker Support** - Containerization
- [ ] **API Rate Limiting** - Request throttling
- [ ] **Logging System** - Comprehensive logs
- [ ] **Backup & Restore** - Data management
- [ ] **Multi-tenant Support** - Organization support

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Documentation**: [Wiki](link-to-wiki)
- **Issues**: [GitHub Issues](link-to-issues)
- **Discord**: [Community Server](link-to-discord)

---

**Made with ❤️ by [Your Name]**
