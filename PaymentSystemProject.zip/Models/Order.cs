
using System;

namespace PaymentSystem.Models
{
    public class Order
    {
        public Guid Id { get; set; }
        public int ProductId { get; set; }
        public decimal Amount { get; set; }
        public string CustomerEmail { get; set; }
        public DateTime OrderDate { get; set; }
        public OrderStatus Status { get; set; }
        public string DistributedCode { get; set; }
    }
}
