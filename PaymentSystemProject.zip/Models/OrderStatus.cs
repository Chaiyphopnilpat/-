
namespace PaymentSystem.Models
{
    public enum OrderStatus
    {
        Pending,
        Paid,
        CodeDistributed,
        Failed
    }
}
