
# User Guide

This guide explains how to use the PaymentSystem API for placing orders and receiving product codes.

- Retrieve product list with GET `/api/orderapi/products`
- Submit payment request with POST `/api/orderapi/checkout`
- Receive confirmation and product code by email and API response
