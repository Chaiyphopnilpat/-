
# API Documentation

## GET /api/orderapi/products

- Description: Retrieve all available products
- Response: JSON array of Product objects

## POST /api/orderapi/checkout

- Description: Process payment and distribute product code
- Request Body:
  ```json
  {
    "ProductId": 1,
    "CustomerEmail": "customer@example.com",
    "PaymentToken": "tok_sample"
  }
  ```
- Response:
  ```json
  {
    "IsSuccess": true,
    "Message": "Payment successful and code distributed!",
    "Code": "CODE-001",
    "OrderId": "guid",
    "ProductName": "C# Basic Course"
  }
  ```
