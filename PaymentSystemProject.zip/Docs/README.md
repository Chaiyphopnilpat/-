
# PaymentSystem API

This is a sample ASP.NET Core Web API project for handling product orders, payment processing, code distribution, and email notifications.

## Setup and Run

1. Install .NET 6 SDK or later
2. Open the project folder in Visual Studio or VS Code
3. Run `dotnet restore` to install dependencies
4. Run `dotnet run` to start the API server
5. Access API endpoints at `http://localhost:5000/api/orderapi/`

## API Endpoints

- GET `/api/orderapi/products`: Get list of products
- POST `/api/orderapi/checkout`: Process checkout and payment

## Project Structure

- Controllers: API controllers
- Models: Data models for products and orders
- Services: Business logic for payments, code distribution, and email
