
using System;
using System.Threading.Tasks;

namespace PaymentSystem.Services
{
    public interface ICodeDistributionService
    {
        Task<string> GetUnusedCodeAsync(Guid orderId);
    }
}
