
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PaymentSystem.Services
{
    public class CodeDistributionService : ICodeDistributionService
    {
        private Queue<string> _codes = new Queue<string>(new[] { "CODE-001", "CODE-002", "CODE-003" });

        public async Task<string> GetUnusedCodeAsync(Guid orderId)
        {
            await Task.Delay(200); // Simulate DB or network delay
            if (_codes.Count > 0)
            {
                return _codes.Dequeue();
            }
            return null;
        }
    }
}
