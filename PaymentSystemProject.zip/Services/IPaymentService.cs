
using System.Threading.Tasks;
using PaymentSystem.Models;

namespace PaymentSystem.Services
{
    public interface IPaymentService
    {
        Task<(bool IsSuccess, string Message, string TransactionId)> ProcessPayment(Order order, string paymentToken);
    }
}
