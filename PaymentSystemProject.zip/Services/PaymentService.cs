
using System.Threading.Tasks;
using PaymentSystem.Models;

namespace PaymentSystem.Services
{
    public class PaymentService : IPaymentService
    {
        public async Task<(bool IsSuccess, string Message, string TransactionId)> ProcessPayment(Order order, string paymentToken)
        {
            // Mock payment processing: always success
            await Task.Delay(500);
            return (true, "Payment processed successfully.", "TXN123456789");
        }
    }
}
