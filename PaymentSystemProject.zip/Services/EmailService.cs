
using System;
using System.Threading.Tasks;

namespace PaymentSystem.Services
{
    public class EmailService : IEmailService
    {
        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            await Task.Delay(200); // Simulate sending email
            Console.WriteLine($"Email sent to {toEmail} with subject '{subject}'.");
        }
    }
}
