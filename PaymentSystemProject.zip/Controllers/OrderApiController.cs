
using Microsoft.AspNetCore.Mvc;
using PaymentSystem.Models;
using PaymentSystem.Services;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace PaymentSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderApiController : ControllerBase
    {
        private readonly IPaymentService _paymentService;
        private readonly ICodeDistributionService _codeDistributionService;
        private readonly IEmailService _emailService;

        private static List<Product> _mockProducts = new List<Product>
        {
            new Product { Id = 1, Name = "C# Basic Course", Price = 999.00m, Description = "Basic C# course for beginners" },
            new Product { Id = 2, Name = "Web API E-book", Price = 499.00m, Description = "E-book on building Web API" }
        };

        private static List<Order> _mockOrders = new List<Order>();
        private static object _orderLock = new object();

        public OrderApiController(IPaymentService paymentService, ICodeDistributionService codeDistributionService, IEmailService emailService)
        {
            _paymentService = paymentService;
            _codeDistributionService = codeDistributionService;
            _emailService = emailService;
        }

        public class CheckoutRequest
        {
            public int ProductId { get; set; }
            public string CustomerEmail { get; set; }
            public string PaymentToken { get; set; }
        }

        public class CheckoutResponse
        {
            public bool IsSuccess { get; set; }
            public string Message { get; set; }
            public string Code { get; set; }
            public Guid OrderId { get; set; }
            public string ProductName { get; set; }
        }

        [HttpGet("products")]
        public ActionResult<IEnumerable<Product>> GetProducts()
        {
            return Ok(_mockProducts);
        }

        [HttpPost("checkout")]
        public async Task<ActionResult<CheckoutResponse>> ProcessCheckout([FromBody] CheckoutRequest request)
        {
            var product = _mockProducts.Find(p => p.Id == request.ProductId);
            if (product == null)
            {
                return NotFound(new CheckoutResponse { IsSuccess = false, Message = "Product not found." });
            }

            var order = new Order
            {
                Id = Guid.NewGuid(),
                ProductId = product.Id,
                Amount = product.Price,
                CustomerEmail = request.CustomerEmail,
                OrderDate = DateTime.UtcNow,
                Status = OrderStatus.Pending
            };

            lock (_orderLock)
            {
                _mockOrders.Add(order);
            }

            var paymentResult = await _paymentService.ProcessPayment(order, request.PaymentToken);

            if (paymentResult.IsSuccess)
            {
                order.Status = OrderStatus.Paid;
                var code = await _codeDistributionService.GetUnusedCodeAsync(order.Id);
                if (code != null)
                {
                    order.DistributedCode = code;
                    order.Status = OrderStatus.CodeDistributed;
                    string emailSubject = $"Your code for {product.Name}";
                    string emailBody = $"Dear Customer,\n\nYour payment is successful! Here is your code: <strong>{code}</strong>\n\nThank you.";
                    await _emailService.SendEmailAsync(request.CustomerEmail, emailSubject, emailBody);

                    return Ok(new CheckoutResponse
                    {
                        IsSuccess = true,
                        Message = "Payment successful and code distributed!",
                        Code = code,
                        OrderId = order.Id,
                        ProductName = product.Name
                    });
                }
                else
                {
                    order.Status = OrderStatus.Failed;
                    return StatusCode(500, new CheckoutResponse { IsSuccess = false, Message = "No unused codes available. Please contact support." });
                }
            }
            else
            {
                order.Status = OrderStatus.Failed;
                return BadRequest(new CheckoutResponse { IsSuccess = false, Message = paymentResult.Message });
            }
        }
    }
}
