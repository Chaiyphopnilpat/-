TimeLangCompiler.cs

ตัวแปลงภาษา TimeLang

(ไฟล์นี้เป็นตัวอย่างเนื้อหา)