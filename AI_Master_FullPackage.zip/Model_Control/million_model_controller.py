# Python code to control 1 million models
print('Init models...')