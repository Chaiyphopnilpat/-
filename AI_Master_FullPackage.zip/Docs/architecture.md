# System Architecture
Overview of all components.