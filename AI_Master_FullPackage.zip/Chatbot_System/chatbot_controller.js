// JS chatbot controller
function startBot() {}