# TimeLang Energy-Aware System

This project demonstrates the TimeLang compiler and agent system for energy-efficient computing.