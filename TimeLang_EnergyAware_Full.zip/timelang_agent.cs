public void ComputeEnergy(double tesla) {
    const double mu0 = 4e-7 * Math.PI;
    const double h = 6.626e-34;
    double energy = (tesla * tesla) / (2 * mu0);
    double freq = energy / h;
    if (IsThermalPeak()) {
        Thread.Sleep(50);
    }
    double bits = (freq * h) / 0.1;
    Console.WriteLine($"Tesla: {tesla} T");
    Console.WriteLine($"Energy: {energy:E} J");
    Console.WriteLine($"Freq: {freq:E} Hz");
    Console.WriteLine($"Bits: {bits:F3}");
}
