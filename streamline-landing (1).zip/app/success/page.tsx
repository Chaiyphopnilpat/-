"use client"

import { useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, ArrowRight } from "lucide-react"
import { useRouter } from "next/navigation"

export default function SuccessPage() {
  const router = useRouter()

  useEffect(() => {
    // Auto redirect after 5 seconds
    const timer = setTimeout(() => {
      router.push("/dashboard")
    }, 5000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="cyber-border bg-black/80 max-w-md w-full text-center">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <div className="p-4 rounded-full cyber-glow bg-green-900/20">
              <CheckCircle className="h-16 w-16 text-green-400" />
            </div>
          </div>
          <CardTitle className="text-2xl text-green-400 terminal-text">🎉 SUBSCRIPTION ACTIVATED</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-green-300 terminal-text">
            Welcome to Cyber AI Pro! Your subscription has been successfully activated.
          </p>
          <div className="space-y-2 text-sm text-green-300 terminal-text">
            <p>✅ Unlimited AI Models</p>
            <p>✅ Real-time Monitoring</p>
            <p>✅ Advanced Analytics</p>
            <p>✅ Priority Support</p>
          </div>
          <Button onClick={() => router.push("/dashboard")} className="w-full cyber-button terminal-text">
            ACCESS CONTROL PANEL
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <p className="text-xs text-green-600 terminal-text">Redirecting automatically in 5 seconds...</p>
        </CardContent>
      </Card>
    </div>
  )
}
