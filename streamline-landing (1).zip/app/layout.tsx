import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/toaster"
import { CartProvider } from "@/hooks/use-cart"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "🧠 Cyber AI Control Panel",
  description: "Advanced AI Model Management System",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-black text-green-400 min-h-screen`}>
        <CartProvider>
          <div className="cyber-grid-bg">{children}</div>
          <Toaster />
        </CartProvider>
      </body>
    </html>
  )
}
