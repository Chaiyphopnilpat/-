"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Grid, List, Star, ExternalLink, Bot, Zap, FileText, Globe } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface Product {
  id: string
  name: string
  category: string
  price: number
  license: string
  description: string
  features: string[]
  source: string
  tags: string[]
  demo_link: string
  ai_integration: string
  rating?: number
  users?: string
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const router = useRouter()

  useEffect(() => {
    // Demo products data
    const demoProducts: Product[] = [
      {
        id: "ai-writer-elite",
        name: "AI Writer Elite",
        category: "Content Writing",
        price: 19.99,
        license: "Monthly Subscription",
        description: "AI-powered writing assistant with real-time SEO suggestions.",
        features: ["Long-form Content", "SEO Optimization", "Multilingual"],
        source: "ProductHunt",
        tags: ["AI", "Content", "SaaS", "Copywriting"],
        demo_link: "https://aiwriterelite.com/demo",
        ai_integration: "GPT-4, Claude 3.5",
        rating: 4.9,
        users: "15K+",
      },
      {
        id: "code-assistant-pro",
        name: "Code Assistant Pro",
        category: "Development",
        price: 29.99,
        license: "Monthly Subscription",
        description: "Advanced AI coding companion with multi-language support.",
        features: ["Code Generation", "Bug Detection", "Refactoring"],
        source: "GitHub",
        tags: ["AI", "Development", "Coding", "Productivity"],
        demo_link: "https://codeassistant.dev/demo",
        ai_integration: "Codex, GPT-4",
        rating: 4.8,
        users: "25K+",
      },
      {
        id: "design-genius",
        name: "Design Genius",
        category: "Design",
        price: 24.99,
        license: "Monthly Subscription",
        description: "AI-powered design tool for creating stunning visuals.",
        features: ["Auto Design", "Brand Kit", "Templates"],
        source: "Dribbble",
        tags: ["AI", "Design", "Graphics", "Creative"],
        demo_link: "https://designgenius.ai/demo",
        ai_integration: "DALL-E 3, Midjourney",
        rating: 4.7,
        users: "12K+",
      },
    ]

    setProducts(demoProducts)
  }, [])

  const categories = ["All", ...Array.from(new Set(products.map((p) => p.category)))]

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Content Writing":
        return <FileText className="h-5 w-5" />
      case "Development":
        return <Bot className="h-5 w-5" />
      case "Design":
        return <Zap className="h-5 w-5" />
      default:
        return <Globe className="h-5 w-5" />
    }
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => router.push("/dashboard")}
              variant="outline"
              className="cyber-border text-green-400 border-green-400 bg-transparent"
            >
              ← BACK TO CONTROL PANEL
            </Button>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
              variant="outline"
              className="cyber-border text-green-400 border-green-400 bg-transparent"
            >
              {viewMode === "grid" ? <List className="h-4 w-4" /> : <Grid className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Title */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-green-400 terminal-text cyber-glow">🤖 AI PRODUCTS MARKETPLACE</h1>
          <p className="text-green-300 terminal-text max-w-2xl mx-auto">
            Discover and deploy cutting-edge AI tools for your workflow
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-green-400" />
            <Input
              placeholder="Search AI products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 cyber-border bg-black/50 text-green-400 terminal-text"
            />
          </div>

          <div className="flex gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                variant={selectedCategory === category ? "default" : "outline"}
                className={`terminal-text ${
                  selectedCategory === category
                    ? "cyber-button cyber-glow"
                    : "cyber-border text-green-400 border-green-400 bg-transparent"
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Products Grid/List */}
        <div
          className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"}`}
        >
          {filteredProducts.map((product) => (
            <Card key={product.id} className="cyber-border bg-black/80 hover:cyber-glow transition-all">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    {getCategoryIcon(product.category)}
                    <div>
                      <CardTitle className="text-green-400 terminal-text">{product.name}</CardTitle>
                      <CardDescription className="text-green-300">{product.category}</CardDescription>
                    </div>
                  </div>
                  <Badge className="bg-blue-900 text-blue-400 border-blue-400 terminal-text">{product.source}</Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <p className="text-green-300 terminal-text text-sm">{product.description}</p>

                <div className="flex flex-wrap gap-1">
                  {product.features.slice(0, 3).map((feature) => (
                    <Badge
                      key={feature}
                      variant="outline"
                      className="cyber-border text-green-300 terminal-text text-xs"
                    >
                      {feature}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold text-green-400 terminal-text">
                    ${product.price}
                    <span className="text-sm text-green-300">/mo</span>
                  </div>
                  {product.rating && (
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-green-400 terminal-text">{product.rating}</span>
                      <span className="text-green-300 terminal-text text-sm">({product.users})</span>
                    </div>
                  )}
                </div>

                <div className="text-xs text-green-300 terminal-text">
                  <strong>AI Integration:</strong> {product.ai_integration}
                </div>

                <div className="flex space-x-2">
                  <Button asChild className="flex-1 cyber-button terminal-text">
                    <Link href={`/products/${product.id}`}>VIEW DETAILS</Link>
                  </Button>

                  <Button
                    onClick={() => window.open(product.demo_link, "_blank")}
                    variant="outline"
                    className="cyber-border text-blue-400 border-blue-400 bg-transparent"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-green-400 terminal-text">{products.length}</div>
              <div className="text-green-300 terminal-text">AI Products</div>
            </CardContent>
          </Card>

          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-blue-400 terminal-text">{categories.length - 1}</div>
              <div className="text-green-300 terminal-text">Categories</div>
            </CardContent>
          </Card>

          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-purple-400 terminal-text">52K+</div>
              <div className="text-green-300 terminal-text">Active Users</div>
            </CardContent>
          </Card>

          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-yellow-400 terminal-text">4.8</div>
              <div className="text-green-300 terminal-text">Avg Rating</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
