"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowRight,
  CheckCircle,
  Star,
  FileText,
  Search,
  Play,
  ExternalLink,
  Bot,
  Sparkles,
  TrendingUp,
  Languages,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

interface ProductData {
  id: string
  name: string
  category: string
  price: number
  license: string
  description: string
  features: string[]
  source: string
  tags: string[]
  demo_link: string
  ai_integration: string
}

export default function AIWriterElitePage() {
  const [product] = useState<ProductData>({
    id: "ai-writer-elite",
    name: "AI Writer Elite",
    category: "Content Writing",
    price: 19.99,
    license: "Monthly Subscription",
    description: "AI-powered writing assistant with real-time SEO suggestions.",
    features: ["Long-form Content", "SEO Optimization", "Multilingual"],
    source: "ProductHunt",
    tags: ["AI", "Content", "SaaS", "Copywriting"],
    demo_link: "https://aiwriterelite.com/demo",
    ai_integration: "GPT-4, Claude 3.5",
  })

  const [isActive, setIsActive] = useState(false)
  const [usage, setUsage] = useState({ requests: 1247, tokens: 892456, uptime: "99.8%" })
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Simulate checking if model is active in the system
    const checkModelStatus = async () => {
      try {
        const response = await fetch("http://localhost:8080/admin/models")
        const data = await response.json()
        setIsActive(data.active.includes(product.name))
      } catch (error) {
        console.log("Using demo mode")
        setIsActive(true) // Demo mode
      }
    }

    checkModelStatus()
  }, [product.name])

  const handleActivateModel = async () => {
    try {
      const response = await fetch("http://localhost:8080/admin/models/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: product.name }),
      })

      if (response.ok) {
        setIsActive(!isActive)
        toast({
          title: `🤖 ${product.name.toUpperCase()} ${!isActive ? "ACTIVATED" : "DEACTIVATED"}`,
          description: `Model is now ${!isActive ? "online" : "offline"}`,
        })
      }
    } catch (error) {
      toast({
        title: "⚠️ CONNECTION ERROR",
        description: "Failed to toggle model status",
        variant: "destructive",
      })
    }
  }

  const handleSubscribe = async () => {
    try {
      const response = await fetch("http://localhost:8080/create-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: localStorage.getItem("userEmail"),
          product_id: product.id,
        }),
      })

      const data = await response.json()
      window.location.href = data.url
    } catch (error) {
      toast({
        title: "💳 PAYMENT ERROR",
        description: "Failed to initialize subscription",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => router.push("/dashboard")}
              variant="outline"
              className="cyber-border text-green-400 border-green-400 bg-transparent"
            >
              ← BACK TO CONTROL PANEL
            </Button>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${isActive ? "bg-green-400" : "bg-red-400"} shadow-lg`} />
            <span className={`terminal-text ${isActive ? "status-active" : "status-inactive"}`}>
              {isActive ? "ONLINE" : "OFFLINE"}
            </span>
          </div>
        </div>

        {/* Hero Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Badge className="bg-blue-900 text-blue-400 border-blue-400 terminal-text">{product.category}</Badge>
                <Badge className="bg-purple-900 text-purple-400 border-purple-400 terminal-text">
                  {product.source}
                </Badge>
              </div>

              <h1 className="text-4xl font-bold text-green-400 terminal-text cyber-glow">{product.name}</h1>

              <p className="text-xl text-green-300 terminal-text">{product.description}</p>

              <div className="flex items-center space-x-4">
                <div className="text-3xl font-bold text-green-400 terminal-text">
                  ${product.price}
                  <span className="text-lg text-green-300">/month</span>
                </div>
                <Badge className="bg-green-900 text-green-400 border-green-400 terminal-text">{product.license}</Badge>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {product.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="cyber-border text-green-300 terminal-text">
                  #{tag}
                </Badge>
              ))}
            </div>

            <div className="flex space-x-4">
              <Button onClick={handleSubscribe} className="cyber-button terminal-text cyber-glow">
                <Sparkles className="mr-2 h-4 w-4" />
                SUBSCRIBE NOW
              </Button>

              <Button
                onClick={handleActivateModel}
                variant="outline"
                className={`cyber-border terminal-text ${
                  isActive ? "border-red-400 text-red-400" : "border-green-400 text-green-400"
                }`}
              >
                {isActive ? "DEACTIVATE" : "ACTIVATE"} MODEL
              </Button>

              <Button
                onClick={() => window.open(product.demo_link, "_blank")}
                variant="outline"
                className="cyber-border text-blue-400 border-blue-400 bg-transparent"
              >
                <Play className="mr-2 h-4 w-4" />
                LIVE DEMO
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-blue-400/20 rounded-3xl blur-3xl"></div>
            <Card className="relative cyber-border bg-black/80 p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-green-400 terminal-text">AI INTEGRATION</h3>
                  <Bot className="h-6 w-6 text-green-400" />
                </div>
                <p className="text-green-300 terminal-text">{product.ai_integration}</p>

                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-green-800">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400 terminal-text">{usage.requests}</div>
                    <div className="text-sm text-green-300 terminal-text">API Requests</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400 terminal-text">
                      {usage.tokens.toLocaleString()}
                    </div>
                    <div className="text-sm text-green-300 terminal-text">Tokens Processed</div>
                  </div>
                </div>

                <div className="text-center pt-2">
                  <div className="text-lg font-semibold text-green-400 terminal-text">{usage.uptime}</div>
                  <div className="text-sm text-green-300 terminal-text">Uptime</div>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Features & Details */}
        <Tabs defaultValue="features" className="w-full">
          <TabsList className="grid w-full grid-cols-4 cyber-border bg-black/80">
            <TabsTrigger
              value="features"
              className="terminal-text data-[state=active]:bg-green-900 data-[state=active]:text-green-400"
            >
              FEATURES
            </TabsTrigger>
            <TabsTrigger
              value="performance"
              className="terminal-text data-[state=active]:bg-green-900 data-[state=active]:text-green-400"
            >
              PERFORMANCE
            </TabsTrigger>
            <TabsTrigger
              value="integration"
              className="terminal-text data-[state=active]:bg-green-900 data-[state=active]:text-green-400"
            >
              INTEGRATION
            </TabsTrigger>
            <TabsTrigger
              value="analytics"
              className="terminal-text data-[state=active]:bg-green-900 data-[state=active]:text-green-400"
            >
              ANALYTICS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="features" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="cyber-border bg-black/80">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <FileText className="h-8 w-8 text-green-400" />
                    <CardTitle className="text-green-400 terminal-text">Long-form Content</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-green-300 terminal-text">
                    Generate comprehensive articles, blog posts, and documentation with advanced AI algorithms.
                  </p>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-green-300 terminal-text">Up to 10,000 words</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-green-300 terminal-text">Multiple formats</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="cyber-border bg-black/80">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <Search className="h-8 w-8 text-blue-400" />
                    <CardTitle className="text-green-400 terminal-text">SEO Optimization</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-green-300 terminal-text">
                    Real-time SEO analysis and suggestions to improve your content's search engine ranking.
                  </p>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-green-300 terminal-text">Keyword optimization</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-green-300 terminal-text">Meta tag generation</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="cyber-border bg-black/80">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <Languages className="h-8 w-8 text-purple-400" />
                    <CardTitle className="text-green-400 terminal-text">Multilingual</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-green-300 terminal-text">
                    Support for 50+ languages with native-level writing quality and cultural context.
                  </p>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-green-300 terminal-text">50+ languages</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-green-300 terminal-text">Cultural adaptation</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="cyber-border bg-black/80">
                <CardHeader>
                  <CardTitle className="text-green-400 terminal-text">SYSTEM METRICS</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-green-300 terminal-text">Response Time</span>
                      <span className="text-green-400 terminal-text">1.2s avg</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-green-400 h-2 rounded-full" style={{ width: "85%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-green-300 terminal-text">Accuracy Rate</span>
                      <span className="text-green-400 terminal-text">97.8%</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-green-400 h-2 rounded-full" style={{ width: "97.8%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-green-300 terminal-text">Uptime</span>
                      <span className="text-green-400 terminal-text">99.8%</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-green-400 h-2 rounded-full" style={{ width: "99.8%" }}></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="cyber-border bg-black/80">
                <CardHeader>
                  <CardTitle className="text-green-400 terminal-text">USAGE STATISTICS</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400 terminal-text">2.4M</div>
                      <div className="text-sm text-green-300 terminal-text">Words Generated</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400 terminal-text">15K</div>
                      <div className="text-sm text-green-300 terminal-text">Active Users</div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-green-800">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-green-400 terminal-text">4.9/5</div>
                      <div className="flex justify-center space-x-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <div className="text-sm text-green-300 terminal-text mt-1">User Rating</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="integration" className="space-y-6">
            <Card className="cyber-border bg-black/80">
              <CardHeader>
                <CardTitle className="text-green-400 terminal-text">API INTEGRATION</CardTitle>
                <CardDescription className="text-green-300">
                  Connect AI Writer Elite to your existing workflow
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gray-900 p-4 rounded cyber-border">
                  <pre className="text-green-400 terminal-text text-sm overflow-x-auto">
                    {`// Initialize AI Writer Elite API
const aiWriter = new AIWriterElite({
  apiKey: 'your-api-key',
  model: 'gpt-4-turbo'
});

// Generate content
const content = await aiWriter.generate({
  prompt: 'Write a blog post about AI',
  length: 'long-form',
  seo: true,
  language: 'en'
});

console.log(content.text);`}
                  </pre>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 cyber-border rounded">
                    <div className="text-green-400 font-semibold terminal-text">REST API</div>
                    <div className="text-sm text-green-300 terminal-text">HTTP/JSON</div>
                  </div>
                  <div className="text-center p-3 cyber-border rounded">
                    <div className="text-green-400 font-semibold terminal-text">WebSocket</div>
                    <div className="text-sm text-green-300 terminal-text">Real-time</div>
                  </div>
                  <div className="text-center p-3 cyber-border rounded">
                    <div className="text-green-400 font-semibold terminal-text">GraphQL</div>
                    <div className="text-sm text-green-300 terminal-text">Flexible</div>
                  </div>
                  <div className="text-center p-3 cyber-border rounded">
                    <div className="text-green-400 font-semibold terminal-text">Webhooks</div>
                    <div className="text-sm text-green-300 terminal-text">Events</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="cyber-border bg-black/80">
                <CardHeader>
                  <CardTitle className="text-green-400 terminal-text">CONTENT ANALYTICS</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-green-300 terminal-text">Readability Score</span>
                      <Badge className="bg-green-900 text-green-400 terminal-text">A+</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-green-300 terminal-text">SEO Score</span>
                      <Badge className="bg-blue-900 text-blue-400 terminal-text">92/100</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-green-300 terminal-text">Engagement Rate</span>
                      <Badge className="bg-purple-900 text-purple-400 terminal-text">+34%</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="cyber-border bg-black/80">
                <CardHeader>
                  <CardTitle className="text-green-400 terminal-text">PERFORMANCE TRENDS</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-5 w-5 text-green-400" />
                      <span className="text-green-300 terminal-text">Content Quality: +15%</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-5 w-5 text-blue-400" />
                      <span className="text-green-300 terminal-text">Generation Speed: +28%</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-5 w-5 text-purple-400" />
                      <span className="text-green-300 terminal-text">User Satisfaction: +22%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Call to Action */}
        <Card className="cyber-border bg-gradient-to-r from-green-900/20 to-blue-900/20 cyber-glow">
          <CardContent className="p-8 text-center space-y-4">
            <h2 className="text-2xl font-bold text-green-400 terminal-text">READY TO DEPLOY AI WRITER ELITE?</h2>
            <p className="text-green-300 terminal-text max-w-2xl mx-auto">
              Join thousands of content creators who have revolutionized their workflow with AI-powered writing
              assistance.
            </p>
            <div className="flex justify-center space-x-4">
              <Button onClick={handleSubscribe} className="cyber-button terminal-text cyber-glow">
                <Sparkles className="mr-2 h-4 w-4" />
                START SUBSCRIPTION
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                onClick={() => window.open(product.demo_link, "_blank")}
                variant="outline"
                className="cyber-border text-green-400 border-green-400 bg-transparent"
              >
                TRY DEMO FIRST
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
