"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Terminal, Plus, Power, PowerOff, Activity, CreditCard, LogOut, Bot, Shield, ShoppingBag } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import { CartSidebar } from "@/components/cart-sidebar"

interface AIModel {
  name: string
  description: string
  status: "active" | "inactive"
}

export default function Dashboard() {
  const [models, setModels] = useState<AIModel[]>([])
  const [activeModels, setActiveModels] = useState<string[]>([])
  const [newModelName, setNewModelName] = useState("")
  const [newModelDescription, setNewModelDescription] = useState("")
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Check authentication
    const auth = localStorage.getItem("auth")
    const email = localStorage.getItem("userEmail")

    if (!auth) {
      router.push("/")
      return
    }

    setUserEmail(email || "")
    loadModels()

    // Simulate real-time updates
    const interval = setInterval(loadModels, 5000)
    return () => clearInterval(interval)
  }, [router])

  const loadModels = async () => {
    try {
      const response = await fetch("http://localhost:8080/admin/models")
      const data = await response.json()

      const modelList = data.models.map((name: string) => ({
        name,
        description: `AI Model: ${name}`,
        status: data.active.includes(name) ? "active" : "inactive",
      }))

      setModels(modelList)
      setActiveModels(data.active)
    } catch (error) {
      console.error("Failed to load models:", error)
      // Fallback demo data
      setModels([
        { name: "GPT-4-Turbo", description: "Advanced language model for complex tasks", status: "active" },
        { name: "Claude-3-Opus", description: "High-performance reasoning model", status: "inactive" },
        { name: "Gemini-Pro", description: "Multimodal AI for text and vision", status: "active" },
      ])
    }
  }

  const toggleModel = async (modelName: string) => {
    try {
      const response = await fetch("http://localhost:8080/admin/models/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: modelName }),
      })

      const data = await response.json()

      toast({
        title: `🤖 MODEL ${data.status.toUpperCase()}`,
        description: `${modelName} is now ${data.status}`,
      })

      loadModels()
    } catch (error) {
      toast({
        title: "⚠️ CONNECTION ERROR",
        description: "Failed to toggle model status",
        variant: "destructive",
      })
    }
  }

  const addModel = async () => {
    if (!newModelName || !newModelDescription) return

    try {
      const response = await fetch("http://localhost:8080/admin/models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newModelName,
          description: newModelDescription,
        }),
      })

      if (response.ok) {
        toast({
          title: "✅ MODEL ADDED",
          description: `${newModelName} has been registered`,
        })
        setNewModelName("")
        setNewModelDescription("")
        loadModels()
      }
    } catch (error) {
      toast({
        title: "❌ FAILED TO ADD MODEL",
        description: "Could not register new model",
        variant: "destructive",
      })
    }
  }

  const handleSubscribe = async () => {
    try {
      const response = await fetch("http://localhost:8080/create-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: userEmail }),
      })

      const data = await response.json()
      window.location.href = data.url
    } catch (error) {
      toast({
        title: "💳 PAYMENT ERROR",
        description: "Failed to initialize subscription",
        variant: "destructive",
      })
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("auth")
    localStorage.removeItem("userEmail")
    router.push("/")
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="p-2 rounded cyber-border cyber-glow">
              <Terminal className="h-8 w-8 text-green-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold terminal-text text-green-400">🧠 CYBER AI CONTROL PANEL</h1>
              <p className="text-green-300 terminal-text">Administrator: {userEmail}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button asChild className="cyber-button terminal-text">
              <Link href="/marketplace">
                <ShoppingBag className="mr-2 h-4 w-4" />
                MARKETPLACE
              </Link>
            </Button>
            <CartSidebar />
            {!isSubscribed && (
              <Button onClick={handleSubscribe} className="cyber-button terminal-text">
                <CreditCard className="mr-2 h-4 w-4" />
                UPGRADE PRO
              </Button>
            )}
            <Button
              onClick={handleLogout}
              variant="outline"
              className="cyber-border text-red-400 border-red-400 bg-transparent"
            >
              <LogOut className="mr-2 h-4 w-4" />
              LOGOUT
            </Button>
          </div>
        </div>

        {/* Quick Access to Marketplace */}
        <Card className="cyber-border bg-gradient-to-r from-green-900/20 to-blue-900/20 cyber-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-green-400 terminal-text">🚀 AI/SAAS MARKETPLACE</h2>
                <p className="text-green-300 terminal-text">100 ready-to-deploy products available</p>
              </div>
              <Button asChild className="cyber-button terminal-text">
                <Link href="/marketplace">EXPLORE MARKETPLACE →</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="cyber-border bg-black/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-300 terminal-text">TOTAL MODELS</p>
                  <p className="text-3xl font-bold text-green-400 terminal-text">{models.length}</p>
                </div>
                <Bot className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="cyber-border bg-black/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-300 terminal-text">ACTIVE MODELS</p>
                  <p className="text-3xl font-bold status-active terminal-text">{activeModels.length}</p>
                </div>
                <Activity className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="cyber-border bg-black/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-300 terminal-text">MARKETPLACE</p>
                  <p className="text-3xl font-bold text-blue-400 terminal-text">100</p>
                </div>
                <ShoppingBag className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="cyber-border bg-black/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-300 terminal-text">SYSTEM STATUS</p>
                  <p className="text-lg font-bold status-active terminal-text">ONLINE</p>
                </div>
                <Shield className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Models Management */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Models List */}
          <div className="lg:col-span-2">
            <Card className="cyber-border bg-black/80">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-green-400 terminal-text">AI MODELS REGISTRY</CardTitle>
                  <CardDescription className="text-green-300">Manage and control your AI models</CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="cyber-button terminal-text">
                      <Plus className="mr-2 h-4 w-4" />
                      ADD MODEL
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="cyber-border bg-black text-green-400">
                    <DialogHeader>
                      <DialogTitle className="terminal-text">REGISTER NEW AI MODEL</DialogTitle>
                      <DialogDescription className="text-green-300">
                        Add a new AI model to the control system
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Input
                        placeholder="Model Name (e.g., GPT-5-Ultra)"
                        value={newModelName}
                        onChange={(e) => setNewModelName(e.target.value)}
                        className="cyber-border bg-black/50 text-green-400 terminal-text"
                      />
                      <Input
                        placeholder="Model Description"
                        value={newModelDescription}
                        onChange={(e) => setNewModelDescription(e.target.value)}
                        className="cyber-border bg-black/50 text-green-400 terminal-text"
                      />
                      <Button onClick={addModel} className="w-full cyber-button terminal-text">
                        REGISTER MODEL
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent className="space-y-4">
                {models.map((model) => (
                  <div
                    key={model.name}
                    className="flex items-center justify-between p-4 rounded cyber-border bg-black/40"
                  >
                    <div className="flex items-center space-x-4">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          model.status === "active" ? "bg-green-400 shadow-green-400" : "bg-red-400 shadow-red-400"
                        } shadow-lg`}
                      />
                      <div>
                        <h3 className="font-semibold text-green-400 terminal-text">{model.name}</h3>
                        <p className="text-sm text-green-300">{model.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge
                        className={`terminal-text ${
                          model.status === "active"
                            ? "bg-green-900 text-green-400 border-green-400"
                            : "bg-red-900 text-red-400 border-red-400"
                        }`}
                      >
                        {model.status.toUpperCase()}
                      </Badge>
                      <Button
                        onClick={() => toggleModel(model.name)}
                        size="sm"
                        className={`cyber-button terminal-text ${
                          model.status === "active" ? "hover:bg-red-900" : "hover:bg-green-900"
                        }`}
                      >
                        {model.status === "active" ? <PowerOff className="h-4 w-4" /> : <Power className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* System Monitor */}
          <div>
            <Card className="cyber-border bg-black/80">
              <CardHeader>
                <CardTitle className="text-green-400 terminal-text">SYSTEM MONITOR</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-green-300 terminal-text">CPU USAGE</span>
                    <span className="text-green-400 terminal-text">73%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-2">
                    <div className="bg-green-400 h-2 rounded-full" style={{ width: "73%" }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-green-300 terminal-text">MEMORY</span>
                    <span className="text-green-400 terminal-text">45%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-2">
                    <div className="bg-green-400 h-2 rounded-full" style={{ width: "45%" }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-green-300 terminal-text">NETWORK</span>
                    <span className="text-green-400 terminal-text">92%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-2">
                    <div className="bg-green-400 h-2 rounded-full" style={{ width: "92%" }}></div>
                  </div>
                </div>

                <div className="pt-4 border-t border-green-800">
                  <h4 className="text-sm font-semibold text-green-400 terminal-text mb-2">MARKETPLACE ACCESS</h4>
                  <div className="space-y-2">
                    <Button asChild className="w-full cyber-button terminal-text text-sm">
                      <Link href="/marketplace">🤖 AI TOOLS (20)</Link>
                    </Button>
                    <Button asChild className="w-full cyber-button terminal-text text-sm">
                      <Link href="/marketplace">⚡ SAAS APPS (20)</Link>
                    </Button>
                    <Button asChild className="w-full cyber-button terminal-text text-sm">
                      <Link href="/marketplace">🌐 WEB SYSTEMS (60)</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
