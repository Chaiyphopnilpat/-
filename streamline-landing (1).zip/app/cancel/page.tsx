"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { XCircle, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

export default function CancelPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="cyber-border bg-black/80 max-w-md w-full text-center">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <div className="p-4 rounded-full bg-red-900/20">
              <XCircle className="h-16 w-16 text-red-400" />
            </div>
          </div>
          <CardTitle className="text-2xl text-red-400 terminal-text">❌ SUBSCRIPTION CANCELLED</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-green-300 terminal-text">
            Your subscription process was cancelled. You can try again anytime.
          </p>
          <div className="space-y-2">
            <Button onClick={() => router.push("/dashboard")} className="w-full cyber-button terminal-text">
              <ArrowLeft className="mr-2 h-4 w-4" />
              RETURN TO DASHBOARD
            </Button>
            <Button
              onClick={() => window.history.back()}
              variant="outline"
              className="w-full cyber-border text-green-400 border-green-400"
            >
              TRY AGAIN
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
