"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useRouter, useParams } from "next/navigation"
import { ArrowLeft, Download, Star, Code, FileText, Zap } from "lucide-react"

export default function CategoryPage() {
  const router = useRouter()
  const params = useParams()
  const [categoryProducts, setCategoryProducts] = useState([])

  const categoryDetails = {
    "ai-features": {
      title: "AI Features & Functions (1-20)",
      description: "Ready-to-use AI components and intelligent features",
      color: "text-green-400",
      icon: <Zap className="h-8 w-8" />,
    },
    "saas-tools": {
      title: "SaaS Tools (21-40)",
      description: "Complete SaaS applications ready for deployment",
      color: "text-blue-400",
      icon: <Code className="h-8 w-8" />,
    },
    "web-systems": {
      title: "Web Systems & APIs (41-60)",
      description: "Backend systems and API solutions",
      color: "text-purple-400",
      icon: <FileText className="h-8 w-8" />,
    },
  }

  const currentCategory = categoryDetails[params.slug] || categoryDetails["ai-features"]

  useEffect(() => {
    // Load category-specific products
    const demoProducts = [
      {
        id: 1,
        name: "AutoReply AI",
        description: "ระบบตอบแชทอัตโนมัติด้วย GPT API รองรับภาษาไทย–อังกฤษ เชื่อมไลน์/Facebook ได้",
        price: 29.99,
        features: ["GPT Integration", "Thai/English", "LINE/Facebook"],
        complexity: "Easy",
      },
      {
        id: 2,
        name: "Emotion Analyzer",
        description: "วิเคราะห์อารมณ์จากข้อความ ใช้ sentiment analysis แสดงผลแบบกราฟ",
        price: 19.99,
        features: ["Sentiment Analysis", "Graph Visualization", "NLP"],
        complexity: "Medium",
      },
      {
        id: 3,
        name: "Smart Tag Generator",
        description: "สร้างแท็กอัตโนมัติจากข้อความ/รูป ใช้ NLP และ Vision AI",
        price: 24.99,
        features: ["NLP", "Vision AI", "Auto Tagging"],
        complexity: "Medium",
      },
    ]

    setCategoryProducts(demoProducts)
  }, [params.slug])

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button
            onClick={() => router.push("/marketplace")}
            variant="outline"
            className="cyber-border text-green-400 border-green-400 bg-transparent"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            BACK TO MARKETPLACE
          </Button>
        </div>

        {/* Category Header */}
        <Card className="cyber-border bg-black/80 cyber-glow">
          <CardHeader>
            <div className="flex items-center space-x-4">
              <div className={`p-3 rounded-lg cyber-border ${currentCategory.color}`}>{currentCategory.icon}</div>
              <div>
                <CardTitle className={`text-2xl terminal-text ${currentCategory.color}`}>
                  {currentCategory.title}
                </CardTitle>
                <CardDescription className="text-green-300 terminal-text">
                  {currentCategory.description}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Products List */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {categoryProducts.map((product) => (
            <Card key={product.id} className="cyber-border bg-black/80 hover:cyber-glow transition-all">
              <CardHeader>
                <CardTitle className="text-green-400 terminal-text">{product.name}</CardTitle>
                <div className="flex items-center justify-between">
                  <Badge className="bg-green-900 text-green-400 border-green-400 terminal-text">
                    {product.complexity}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-green-400 terminal-text">4.8</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <p className="text-green-300 terminal-text text-sm">{product.description}</p>

                <div className="flex flex-wrap gap-1">
                  {product.features.map((feature) => (
                    <Badge
                      key={feature}
                      variant="outline"
                      className="cyber-border text-green-300 terminal-text text-xs"
                    >
                      {feature}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold text-green-400 terminal-text">${product.price}</div>
                  <Button className="cyber-button terminal-text">
                    <Download className="mr-2 h-4 w-4" />
                    GET CODE
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Export Options */}
        <Card className="cyber-border bg-black/80">
          <CardHeader>
            <CardTitle className="text-green-400 terminal-text">BULK EXPORT OPTIONS</CardTitle>
            <CardDescription className="text-green-300">Get the complete package for this category</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button className="cyber-button terminal-text">📄 EXPORT PDF DOCUMENTATION</Button>
              <Button className="cyber-button terminal-text">📊 EXPORT EXCEL DATABASE</Button>
              <Button className="cyber-button terminal-text">💾 DOWNLOAD ALL SOURCE CODE</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
