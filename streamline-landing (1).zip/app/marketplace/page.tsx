"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Star, ExternalLink, Bot, Code, Zap, Globe, Smartphone, TrendingUp, Settings } from "lucide-react"
import { useRouter } from "next/navigation"
import { CartSidebar } from "@/components/cart-sidebar"
import { AddToCartButton } from "@/components/add-to-cart-button"
import { BulkActions } from "@/components/bulk-actions"
import { useCart } from "@/hooks/use-cart"

interface Product {
  id: number
  name: string
  category: string
  description: string
  price: number
  status: "ready" | "development" | "premium"
  tags: string[]
  difficulty: "easy" | "medium" | "hard"
  type: "ai" | "saas" | "api" | "webapp" | "automation"
}

export default function MarketplacePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedType, setSelectedType] = useState("all")
  const router = useRouter()
  const { getTotalItems } = useCart()

  useEffect(() => {
    // Initialize with the first 20 AI features/functions
    const aiProducts: Product[] = [
      {
        id: 1,
        name: "AutoReply AI",
        category: "AI Features",
        description: "ระบบตอบแชทอัตโนมัติด้วย GPT API รองรับภาษาไทย–อังกฤษ เชื่อมไลน์/Facebook ได้",
        price: 29.99,
        status: "ready",
        tags: ["GPT", "Chat", "Thai", "LINE", "Facebook"],
        difficulty: "easy",
        type: "ai",
      },
      {
        id: 2,
        name: "Emotion Analyzer",
        category: "AI Features",
        description: "วิเคราะห์อารมณ์จากข้อความ ใช้ sentiment analysis แสดงผลแบบกราฟ",
        price: 19.99,
        status: "ready",
        tags: ["Sentiment", "Analysis", "Graph", "NLP"],
        difficulty: "medium",
        type: "ai",
      },
      {
        id: 3,
        name: "Smart Tag Generator",
        category: "AI Features",
        description: "สร้างแท็กอัตโนมัติจากข้อความ/รูป ใช้ NLP และ Vision AI",
        price: 24.99,
        status: "ready",
        tags: ["NLP", "Vision", "Tags", "Automation"],
        difficulty: "medium",
        type: "ai",
      },
      {
        id: 4,
        name: "Voice-to-Text SaaS",
        category: "AI Features",
        description: "API แปลงเสียงเป็นข้อความภาษาไทย/อังกฤษ พร้อม timestamp",
        price: 34.99,
        status: "ready",
        tags: ["Voice", "Text", "API", "Thai", "Timestamp"],
        difficulty: "hard",
        type: "saas",
      },
      {
        id: 5,
        name: "Image Caption Bot",
        category: "AI Features",
        description: "บอทสร้างคำอธิบายรูปภาพ ใช้ CLIP + LLaVA",
        price: 39.99,
        status: "ready",
        tags: ["CLIP", "LLaVA", "Image", "Caption", "Bot"],
        difficulty: "hard",
        type: "ai",
      },
      {
        id: 21,
        name: "Invoice Cloud SaaS",
        category: "SaaS Tools",
        description: "ระบบออกใบแจ้งหนี้ออนไลน์",
        price: 49.99,
        status: "ready",
        tags: ["Invoice", "Billing", "Cloud", "Business"],
        difficulty: "medium",
        type: "saas",
      },
      {
        id: 22,
        name: "URL Shortener Pro",
        category: "SaaS Tools",
        description: "SaaS ย่อลิงก์ + วิเคราะห์สถิติ",
        price: 15.99,
        status: "ready",
        tags: ["URL", "Analytics", "Statistics", "Short"],
        difficulty: "easy",
        type: "saas",
      },
      {
        id: 41,
        name: "User Management API",
        category: "Web Systems",
        description: "API จัดการผู้ใช้: Login, Register, Roles",
        price: 29.99,
        status: "ready",
        tags: ["API", "Auth", "Users", "Roles", "Management"],
        difficulty: "medium",
        type: "api",
      },
      {
        id: 61,
        name: "AI News Aggregator",
        category: "Web Projects",
        description: "เว็บรวมข่าวพร้อมวิเคราะห์ความจริงปลอม",
        price: 79.99,
        status: "ready",
        tags: ["News", "AI", "Aggregator", "Fact Check"],
        difficulty: "hard",
        type: "webapp",
      },
      {
        id: 81,
        name: "Custom GPT Plugin",
        category: "Advanced AI",
        description: "ปลั๊กอิน GPT ส่วนตัวสำหรับองค์กร",
        price: 99.99,
        status: "premium",
        tags: ["GPT", "Plugin", "Custom", "Enterprise"],
        difficulty: "hard",
        type: "ai",
      },
    ]

    setProducts(aiProducts)
  }, [])

  const categories = ["All", "AI Features", "SaaS Tools", "Web Systems", "Web Projects", "Advanced AI"]
  const types = [
    { value: "all", label: "All Types", icon: Globe },
    { value: "ai", label: "AI Tools", icon: Bot },
    { value: "saas", label: "SaaS", icon: Zap },
    { value: "api", label: "APIs", icon: Code },
    { value: "webapp", label: "Web Apps", icon: Smartphone },
    { value: "automation", label: "Automation", icon: Settings },
  ]

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory
    const matchesType = selectedType === "all" || product.type === selectedType

    return matchesSearch && matchesCategory && matchesType
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ready":
        return "bg-green-900 text-green-400 border-green-400"
      case "development":
        return "bg-yellow-900 text-yellow-400 border-yellow-400"
      case "premium":
        return "bg-purple-900 text-purple-400 border-purple-400"
      default:
        return "bg-gray-900 text-gray-400 border-gray-400"
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-900 text-green-400"
      case "medium":
        return "bg-yellow-900 text-yellow-400"
      case "hard":
        return "bg-red-900 text-red-400"
      default:
        return "bg-gray-900 text-gray-400"
    }
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => router.push("/dashboard")}
              variant="outline"
              className="cyber-border text-green-400 border-green-400 bg-transparent"
            >
              ← CONTROL PANEL
            </Button>
            <BulkActions products={filteredProducts} selectedCategory={selectedCategory} />
          </div>
          <div className="flex items-center space-x-4">
            <CartSidebar />
            <div className="text-right">
              <div className="text-green-400 terminal-text font-semibold">100 PRODUCTS AVAILABLE</div>
              <div className="text-green-300 terminal-text text-sm">Ready for deployment</div>
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-green-400 terminal-text cyber-glow">🚀 AI/SAAS MARKETPLACE</h1>
          <p className="text-green-300 terminal-text max-w-3xl mx-auto">
            ระบบสมบูรณ์ 100 รายการ พร้อมขาย: AI Features, SaaS Tools, APIs, Web Projects
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-400 terminal-text">
                {products.filter((p) => p.type === "ai").length}
              </div>
              <div className="text-green-300 terminal-text text-sm">AI Tools</div>
            </CardContent>
          </Card>
          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-400 terminal-text">
                {products.filter((p) => p.type === "saas").length}
              </div>
              <div className="text-green-300 terminal-text text-sm">SaaS Products</div>
            </CardContent>
          </Card>
          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-purple-400 terminal-text">
                {products.filter((p) => p.status === "ready").length}
              </div>
              <div className="text-green-300 terminal-text text-sm">Ready to Deploy</div>
            </CardContent>
          </Card>
          <Card className="cyber-border bg-black/80 text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-yellow-400 terminal-text">
                ${products.reduce((sum, p) => sum + p.price, 0).toFixed(0)}
              </div>
              <div className="text-green-300 terminal-text text-sm">Total Value</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-green-400" />
            <Input
              placeholder="Search products, features, or technologies..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 cyber-border bg-black/50 text-green-400 terminal-text"
            />
          </div>

          <Tabs value={selectedType} onValueChange={setSelectedType} className="w-full">
            <TabsList className="grid w-full grid-cols-6 cyber-border bg-black/80">
              {types.map((type) => (
                <TabsTrigger
                  key={type.value}
                  value={type.value}
                  className="terminal-text data-[state=active]:bg-green-900 data-[state=active]:text-green-400 flex items-center space-x-1"
                >
                  <type.icon className="h-4 w-4" />
                  <span className="hidden md:inline">{type.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                className={`terminal-text ${
                  selectedCategory === category
                    ? "cyber-button cyber-glow"
                    : "cyber-border text-green-400 border-green-400 bg-transparent"
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="cyber-border bg-black/80 hover:cyber-glow transition-all">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <CardTitle className="text-green-400 terminal-text text-lg">{product.name}</CardTitle>
                    <CardDescription className="text-green-300 text-sm">{product.category}</CardDescription>
                  </div>
                  <div className="flex flex-col space-y-1">
                    <Badge className={`${getStatusColor(product.status)} terminal-text text-xs`}>
                      {product.status.toUpperCase()}
                    </Badge>
                    <Badge className={`${getDifficultyColor(product.difficulty)} terminal-text text-xs`}>
                      {product.difficulty.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <p className="text-green-300 terminal-text text-sm line-clamp-3">{product.description}</p>

                <div className="flex flex-wrap gap-1">
                  {product.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="outline" className="cyber-border text-green-300 terminal-text text-xs">
                      #{tag}
                    </Badge>
                  ))}
                  {product.tags.length > 3 && (
                    <Badge variant="outline" className="cyber-border text-green-300 terminal-text text-xs">
                      +{product.tags.length - 3}
                    </Badge>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold text-green-400 terminal-text">${product.price}</div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-green-400 terminal-text text-sm">4.8</span>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <AddToCartButton product={product} className="flex-1 cyber-button terminal-text text-xs" />
                  <Button variant="outline" className="cyber-border text-blue-400 border-blue-400 bg-transparent">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center">
          <Button className="cyber-button terminal-text">
            LOAD MORE PRODUCTS
            <TrendingUp className="ml-2 h-4 w-4" />
          </Button>
          <p className="text-green-300 terminal-text text-sm mt-2">
            Showing {filteredProducts.length} of 100 total products
          </p>
        </div>

        {/* Categories Overview */}
        <Card className="cyber-border bg-black/80">
          <CardHeader>
            <CardTitle className="text-green-400 terminal-text">PRODUCT CATEGORIES</CardTitle>
            <CardDescription className="text-green-300">Complete breakdown of available solutions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="text-center p-4 cyber-border rounded">
                <div className="text-green-400 font-bold terminal-text text-lg">1-20</div>
                <div className="text-green-300 terminal-text text-sm">AI Features</div>
                <div className="text-green-300 terminal-text text-xs">AutoReply, Emotion Analysis</div>
              </div>
              <div className="text-center p-4 cyber-border rounded">
                <div className="text-blue-400 font-bold terminal-text text-lg">21-40</div>
                <div className="text-green-300 terminal-text text-sm">SaaS Tools</div>
                <div className="text-green-300 terminal-text text-xs">Invoice, URL Shortener</div>
              </div>
              <div className="text-center p-4 cyber-border rounded">
                <div className="text-purple-400 font-bold terminal-text text-lg">41-60</div>
                <div className="text-green-300 terminal-text text-sm">Web & APIs</div>
                <div className="text-green-300 terminal-text text-xs">User Management, Auth</div>
              </div>
              <div className="text-center p-4 cyber-border rounded">
                <div className="text-yellow-400 font-bold terminal-text text-lg">61-80</div>
                <div className="text-green-300 terminal-text text-sm">Web Projects</div>
                <div className="text-green-300 terminal-text text-xs">News Aggregator, LMS</div>
              </div>
              <div className="text-center p-4 cyber-border rounded">
                <div className="text-red-400 font-bold terminal-text text-lg">81-100</div>
                <div className="text-green-300 terminal-text text-sm">Advanced AI</div>
                <div className="text-green-300 terminal-text text-xs">Custom GPT, Voice Clone</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
