"use client"

import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import { ShoppingCart, Check } from "lucide-react"

interface Product {
  id: number
  name: string
  price: number
  category: string
  type: string
  description: string
  tags: string[]
}

interface AddToCartButtonProps {
  product: Product
  variant?: "default" | "outline"
  size?: "default" | "sm" | "lg"
  className?: string
}

export function AddToCartButton({
  product,
  variant = "default",
  size = "default",
  className = "",
}: AddToCartButtonProps) {
  const { addToCart, isInCart } = useCart()
  const { toast } = useToast()
  const inCart = isInCart(product.id)

  const handleAddToCart = () => {
    if (inCart) return

    addToCart(product)

    toast({
      title: "🛒 ADDED TO CART",
      description: `${product.name} added to bulk purchase`,
    })
  }

  return (
    <Button
      onClick={handleAddToCart}
      variant={variant}
      size={size}
      disabled={inCart}
      className={`${className} ${inCart ? "opacity-50" : ""}`}
    >
      {inCart ? (
        <>
          <Check className="mr-2 h-4 w-4" />
          IN CART
        </>
      ) : (
        <>
          <ShoppingCart className="mr-2 h-4 w-4" />
          ADD TO CART
        </>
      )}
    </Button>
  )
}
