"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { useCart } from "@/hooks/use-cart"
import { ShoppingCart, Minus, Plus, Trash2, CreditCard, Package, Percent } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function CartSidebar() {
  const { items, removeFromCart, updateQuantity, clearCart, getTotalItems, getTotalPrice, getDiscountedPrice } =
    useCart()
  const { toast } = useToast()
  const [isOpen, setIsOpen] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  const totalItems = getTotalItems()
  const originalPrice = getTotalPrice()
  const discountedPrice = getDiscountedPrice()
  const savings = originalPrice - discountedPrice

  const handleCheckout = async () => {
    setIsProcessing(true)

    try {
      // Simulate checkout process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "🛒 BULK ORDER PROCESSING",
        description: `${totalItems} products added to your deployment queue`,
      })

      clearCart()
      setIsOpen(false)
    } catch (error) {
      toast({
        title: "❌ CHECKOUT FAILED",
        description: "Failed to process bulk order",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const getBulkDiscountTier = () => {
    if (totalItems >= 20) return { tier: "ENTERPRISE", discount: 30, color: "text-purple-400" }
    if (totalItems >= 10) return { tier: "PROFESSIONAL", discount: 20, color: "text-blue-400" }
    if (totalItems >= 5) return { tier: "STARTER", discount: 10, color: "text-green-400" }
    return { tier: "INDIVIDUAL", discount: 0, color: "text-gray-400" }
  }

  const discountTier = getBulkDiscountTier()

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button className="cyber-button terminal-text relative">
          <ShoppingCart className="h-4 w-4 mr-2" />
          CART
          {totalItems > 0 && (
            <Badge className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">
              {totalItems}
            </Badge>
          )}
        </Button>
      </SheetTrigger>

      <SheetContent className="w-[500px] cyber-border bg-black text-green-400 overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="text-green-400 terminal-text flex items-center">
            <ShoppingCart className="mr-2 h-5 w-5" />
            BULK PURCHASE CART
          </SheetTitle>
          <SheetDescription className="text-green-300 terminal-text">
            {totalItems} products selected for deployment
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 mt-6">
          {/* Bulk Discount Tier */}
          <Card className="cyber-border bg-black/80">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Percent className="h-5 w-5 text-yellow-400" />
                  <span className="terminal-text text-green-300">BULK TIER:</span>
                </div>
                <Badge className={`terminal-text ${discountTier.color} bg-transparent border`}>
                  {discountTier.tier} ({discountTier.discount}% OFF)
                </Badge>
              </div>
              {discountTier.discount > 0 && (
                <div className="mt-2 text-sm text-green-300 terminal-text">
                  💰 You're saving ${savings.toFixed(2)} with bulk pricing!
                </div>
              )}
            </CardContent>
          </Card>

          {/* Cart Items */}
          <div className="space-y-4">
            {items.length === 0 ? (
              <Card className="cyber-border bg-black/80">
                <CardContent className="p-8 text-center">
                  <Package className="h-12 w-12 text-green-400 mx-auto mb-4" />
                  <p className="text-green-300 terminal-text">Your cart is empty</p>
                  <p className="text-green-300 terminal-text text-sm mt-2">
                    Add AI/SaaS products to start building your package
                  </p>
                </CardContent>
              </Card>
            ) : (
              items.map((item) => (
                <Card key={item.id} className="cyber-border bg-black/80">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-green-400 terminal-text">{item.name}</h4>
                          <p className="text-sm text-green-300 terminal-text">{item.category}</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {item.tags.slice(0, 2).map((tag) => (
                              <Badge
                                key={tag}
                                variant="outline"
                                className="cyber-border text-green-300 terminal-text text-xs"
                              >
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Button
                          onClick={() => removeFromCart(item.id)}
                          variant="outline"
                          size="sm"
                          className="cyber-border text-red-400 border-red-400 bg-transparent"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            variant="outline"
                            size="sm"
                            className="cyber-border text-green-400 border-green-400 bg-transparent w-8 h-8 p-0"
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value) || 1)}
                            className="w-16 text-center cyber-border bg-black/50 text-green-400 terminal-text"
                            min="1"
                          />
                          <Button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            variant="outline"
                            size="sm"
                            className="cyber-border text-green-400 border-green-400 bg-transparent w-8 h-8 p-0"
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-green-400 terminal-text">
                            ${(item.price * item.quantity).toFixed(2)}
                          </div>
                          <div className="text-sm text-green-300 terminal-text">${item.price} each</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Cart Summary */}
          {items.length > 0 && (
            <Card className="cyber-border bg-black/80 cyber-glow">
              <CardHeader>
                <CardTitle className="text-green-400 terminal-text">ORDER SUMMARY</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-green-300 terminal-text">
                    <span>Subtotal ({totalItems} items):</span>
                    <span>${originalPrice.toFixed(2)}</span>
                  </div>

                  {savings > 0 && (
                    <div className="flex justify-between text-yellow-400 terminal-text">
                      <span>Bulk Discount ({discountTier.discount}%):</span>
                      <span>-${savings.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="border-t border-green-800 pt-2">
                    <div className="flex justify-between text-lg font-bold text-green-400 terminal-text">
                      <span>Total:</span>
                      <span>${discountedPrice.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Button
                    onClick={handleCheckout}
                    disabled={isProcessing}
                    className="w-full cyber-button terminal-text cyber-glow"
                  >
                    <CreditCard className="mr-2 h-4 w-4" />
                    {isProcessing ? "PROCESSING..." : "CHECKOUT BULK ORDER"}
                  </Button>

                  <Button
                    onClick={clearCart}
                    variant="outline"
                    className="w-full cyber-border text-red-400 border-red-400 bg-transparent"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    CLEAR CART
                  </Button>
                </div>

                {/* Bulk Benefits */}
                <div className="pt-4 border-t border-green-800">
                  <h4 className="text-sm font-semibold text-green-400 terminal-text mb-2">BULK PURCHASE BENEFITS:</h4>
                  <div className="space-y-1 text-xs text-green-300 terminal-text">
                    <div>✅ Complete source code access</div>
                    <div>✅ Documentation & setup guides</div>
                    <div>✅ 1-year updates included</div>
                    <div>✅ Priority technical support</div>
                    {totalItems >= 10 && <div>🎁 Bonus: Custom deployment assistance</div>}
                    {totalItems >= 20 && <div>🎁 Bonus: White-label licensing</div>}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}
