"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import { Package, ShoppingCart, Star } from "lucide-react"

interface Product {
  id: number
  name: string
  price: number
  category: string
  type: string
  description: string
  tags: string[]
}

interface BulkActionsProps {
  products: Product[]
  selectedCategory?: string
}

export function BulkActions({ products, selectedCategory }: BulkActionsProps) {
  const [selectedProducts, setSelectedProducts] = useState<number[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const { addToCart, getTotalItems } = useCart()
  const { toast } = useToast()

  const handleSelectAll = () => {
    if (selectedProducts.length === products.length) {
      setSelectedProducts([])
    } else {
      setSelectedProducts(products.map((p) => p.id))
    }
  }

  const handleSelectProduct = (productId: number) => {
    setSelectedProducts((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId],
    )
  }

  const handleBulkAddToCart = () => {
    const selectedProductsData = products.filter((p) => selectedProducts.includes(p.id))

    selectedProductsData.forEach((product) => {
      addToCart(product)
    })

    toast({
      title: "🛒 BULK ADDED TO CART",
      description: `${selectedProducts.length} products added to your cart`,
    })

    setSelectedProducts([])
    setIsOpen(false)
  }

  const totalPrice = products.filter((p) => selectedProducts.includes(p.id)).reduce((sum, p) => sum + p.price, 0)

  const getBulkDiscount = () => {
    const count = selectedProducts.length
    if (count >= 20) return 30
    if (count >= 10) return 20
    if (count >= 5) return 10
    return 0
  }

  const discount = getBulkDiscount()
  const discountedPrice = totalPrice * (1 - discount / 100)

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="cyber-button terminal-text">
          <Package className="mr-2 h-4 w-4" />
          BULK SELECT
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-4xl cyber-border bg-black text-green-400 max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-green-400 terminal-text flex items-center">
            <Package className="mr-2 h-5 w-5" />
            BULK PRODUCT SELECTION
          </DialogTitle>
          <DialogDescription className="text-green-300 terminal-text">
            Select multiple products for bulk purchase with automatic discounts
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Bulk Actions Header */}
          <Card className="cyber-border bg-black/80">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Checkbox
                    checked={selectedProducts.length === products.length}
                    onCheckedChange={handleSelectAll}
                    className="border-green-400"
                  />
                  <span className="terminal-text text-green-300">Select All ({products.length} products)</span>
                </div>
                <div className="flex items-center space-x-4">
                  <Badge className="bg-blue-900 text-blue-400 border-blue-400 terminal-text">
                    {selectedProducts.length} Selected
                  </Badge>
                  {discount > 0 && (
                    <Badge className="bg-yellow-900 text-yellow-400 border-yellow-400 terminal-text">
                      {discount}% Bulk Discount
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Product Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => (
              <Card
                key={product.id}
                className={`cyber-border bg-black/80 cursor-pointer transition-all ${
                  selectedProducts.includes(product.id) ? "cyber-glow ring-2 ring-green-400" : ""
                }`}
                onClick={() => handleSelectProduct(product.id)}
              >
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <Checkbox
                        checked={selectedProducts.includes(product.id)}
                        onCheckedChange={() => handleSelectProduct(product.id)}
                        className="border-green-400"
                        onClick={(e) => e.stopPropagation()}
                      />
                      <Badge className="bg-purple-900 text-purple-400 border-purple-400 terminal-text text-xs">
                        {product.category}
                      </Badge>
                    </div>

                    <div>
                      <h4 className="font-semibold text-green-400 terminal-text text-sm">{product.name}</h4>
                      <p className="text-xs text-green-300 terminal-text line-clamp-2 mt-1">{product.description}</p>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {product.tags.slice(0, 2).map((tag) => (
                        <Badge
                          key={tag}
                          variant="outline"
                          className="cyber-border text-green-300 terminal-text text-xs"
                        >
                          #{tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="text-lg font-bold text-green-400 terminal-text">${product.price}</div>
                      <div className="flex items-center space-x-1">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-green-400 terminal-text text-xs">4.8</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Bulk Purchase Summary */}
          {selectedProducts.length > 0 && (
            <Card className="cyber-border bg-black/80 cyber-glow">
              <CardHeader>
                <CardTitle className="text-green-400 terminal-text flex items-center">
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  BULK PURCHASE SUMMARY
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400 terminal-text">{selectedProducts.length}</div>
                    <div className="text-sm text-green-300 terminal-text">Products</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400 terminal-text">${totalPrice.toFixed(2)}</div>
                    <div className="text-sm text-green-300 terminal-text">Original Price</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-400 terminal-text">{discount}%</div>
                    <div className="text-sm text-green-300 terminal-text">Bulk Discount</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400 terminal-text">${discountedPrice.toFixed(2)}</div>
                    <div className="text-sm text-green-300 terminal-text">Final Price</div>
                  </div>
                </div>

                {discount > 0 && (
                  <div className="text-center p-3 cyber-border rounded bg-yellow-900/20">
                    <div className="text-yellow-400 terminal-text font-semibold">
                      💰 You save ${(totalPrice - discountedPrice).toFixed(2)} with bulk pricing!
                    </div>
                  </div>
                )}

                <Button
                  onClick={handleBulkAddToCart}
                  className="w-full cyber-button terminal-text cyber-glow"
                  disabled={selectedProducts.length === 0}
                >
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  ADD {selectedProducts.length} PRODUCTS TO CART
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
